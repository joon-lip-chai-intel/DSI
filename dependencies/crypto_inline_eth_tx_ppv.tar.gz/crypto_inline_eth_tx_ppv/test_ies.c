/*-
 *   BSD LICENSE
 *
 *   Copyright(c) 2016 Intel Corporation. All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "main.h"
#include "common.h"

extern bool qat_order;
uint32_t acl_trig_id;
int acl_tbl_index_e;
int logical_port[NUM_HLP_PORTS ];

int delete_snake(void)
{
	char cliCmd[128];
	int i, ret;
	int sw = 0;

	sprintf(cliCmd,"debug snake destroy");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);

	for(i=0;i<MAX_HLP_PORTS;i++)
	{
		ret = ies_port_set_attr(sw, i, IES_PA_DEF_DEST_PORT, &logical_port[i]);
        if(ret != IES_OK)
        {
            debug_print("ies_port_set_attr() failed. errorno = %d\n", ret);
        }
	}
}


int create_snake(void)
{
	int end_port = start_port + num_use_ports;
	char snake_port_command_str[128], snake_port_str[4];
	char cliCmd[128];
	int first_port = 1;
	int i;
	int ret;
	int sw = 0;
			
	debug_print("start_port %d end_port %d\n",	start_port,end_port);
	for(i=0;i<MAX_HLP_PORTS;i++)
	{
		if((i < start_port || i >= end_port) && ( i< 8 || i > 11))
		{
			if(first_port)
			{
				first_port=0;
				snake_start_port = i;
				sprintf(snake_port_command_str,"debug snake set chain ");
				sprintf(snake_port_str,"%d",i);
			}
			else
			{
				sprintf(snake_port_str,",%d",i);
			}
			strcat(snake_port_command_str,snake_port_str);
		}
	}
	debug_print("snake port list %s\n",	snake_port_command_str);
	
	sprintf(cliCmd,"debug snake destroy");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	sprintf(cliCmd,"debug snake set fwd-mode dest-port");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	sprintf(cliCmd,"debug snake set wiring lo-plug");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	ies_cli_exec_command(snake_port_command_str, strlen(snake_port_command_str), printf);
	sprintf(cliCmd,"debug snake create");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	sprintf(cliCmd,"debug snake show");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	for(i=start_port;i<end_port;i++)
	{
		ret = ies_port_set_attr(sw, i, IES_PA_DEF_DEST_PORT, &logical_port[i]);
        if(ret != IES_OK)
        {
            debug_print("ies_port_set_attr() failed. errorno = %d\n", ret);
        }
	}
}

static void add_rules_e(int sw, struct ies_acl_rule_info *acl_rule)
{
    int ret, rule_index;
	unsigned int j;
    uint64_t mac_mask = 0xffffffffffff;
	uint64_t clear_pt_smac = 0xDEADBEEF0001;
    
    /*Create rules for DSI Egress traffic*/
    /* Setting SMAC Val to match standard Ixia stream used, Should be changed to match strem used by the test */
    acl_rule->cond.mask.smac = mac_mask;
	
    acl_rule->precedence = 2;
	acl_rule->condition = IES_ACL_MATCH_SMAC; 
    acl_rule->state = IES_ACL_RULE_ENTRY_STATE_VALID;

    /* Create num_hlp_ports rules. Each rule has specific condition values. */
    /* Set action to set trig_id for passthrough egress packets based on matching SMAC */
    for(j = 0; j < num_hlp_ports; j++)
	{
		//Clear Passthrough packets - will go to encrypt port 21 and get passed through
		acl_rule->cond.val.smac = clear_pt_smac;
		acl_rule->action = 	IES_ACL_ACTION_COUNT ;
		if((int)acl_trig_id != -1)
		{
			acl_rule->action |= IES_ACL_ACTION_SET_TRIG_ID;
			acl_rule->act_val.trig_id = 1 << acl_trig_id;
			acl_rule->act_val.trig_id_mask = 1 << acl_trig_id;
		}
		debug_print("Rule id = %d,\tlogical port = %d,\tDMAC = 0x%lx\tSMAC = 0x%lx\n",
						j, acl_rule->act_val.logical_port, acl_rule->cond.val.dmac,
						acl_rule->cond.val.smac);

		ret = ies_acl_add_rule(sw, acl_tbl_index_e, acl_rule, &rule_index);
		if(ret != IES_OK)
		{
			debug_print("ies_acl_add_rule() for tbl_index %d failed. errno = %d\n", acl_tbl_index_e, ret);
		}
		debug_print("ACL rules created for tbl_index %d with rule id = %d\n", acl_tbl_index_e,rule_index);
		updateTestInfo_aclRules(acl_tbl_index_e,rule_index);
	}
}


static void add_rules(int sw, struct ies_acl_rule_info *acl_rule)
{
    int ret;
    unsigned int i,j;
    int rule_index;
	uint64_t mac_mask = 0xffffffffffff;
	uint64_t ipsec_dmac = 0xDEADBEEF001;
   
	/* One rule for IPSec traffic on all ports */
	/* TBD Seperate rules will have to be created for each scenario if default scenario is not sufficient*/
	/*Create rules for ipv4 traffic*/
    
	if(!qat_order)
	{
		acl_rule->cond.val.protocol = 0x32 ;
		acl_rule->cond.mask.protocol = 0xff;
		acl_rule->precedence = 2;
		acl_rule->condition = IES_ACL_MATCH_PROT; 
		acl_rule->action = IES_ACL_ACTION_COUNT |
                       IES_ACL_ACTION_SET_HASH_NEXTHOP |
                       IES_ACL_ACTION_SET_METADATA;
  
		acl_rule->state = IES_ACL_RULE_ENTRY_STATE_VALID;

		i = 0;
		acl_rule->act_val.meta.byte_select = 0x20000000;
		acl_rule->act_val.meta.val[29] = 0x40;
		acl_rule->act_val.meta.mask[29] = 0x40;
		ret = ies_acl_add_rule(sw, acl_tbl_index, acl_rule, &rule_index);
		if(ret != IES_OK)
		{
			debug_print("ies_acl_add_rule() for tbl_index %d failed. errno = %d\n", acl_tbl_index,ret);
			return;
		}
		debug_print("ACL rules created for tbl_index %d with rule id = %d\n", acl_tbl_index,rule_index);
		updateTestInfo_aclRules(acl_tbl_index,rule_index);
	}
	else
	{
		acl_rule->cond.mask.dmac = mac_mask;

		acl_rule->precedence = 2;
		acl_rule->condition = IES_ACL_MATCH_DMAC; 
		acl_rule->state = IES_ACL_RULE_ENTRY_STATE_VALID;

		/*Create 20 rules. Each rule has specific condition values. */
		/* Set action to redirect to different cpk queues*/
		for(j = 0; j < num_hlp_ports; j++)
		{
			acl_rule->cond.val.dmac = ipsec_dmac;
			acl_rule->action = 	IES_ACL_ACTION_COUNT |
							IES_ACL_ACTION_REDIRECT ;
			if((int)acl_trig_id != -1)
			{
				acl_rule->action |= IES_ACL_ACTION_SET_TRIG_ID;
				acl_rule->act_val.trig_id = 1 << acl_trig_id;
				acl_rule->act_val.trig_id_mask = 1 << acl_trig_id;
			}
			acl_rule->act_val.logical_port = logical_port[j];
  
			debug_print("Rule id = %d,\tlogical port = %d,\tDMAC = 0x%lx\tSMAC = 0x%lx\n",
						(num_ports * j) , acl_rule->act_val.logical_port, acl_rule->cond.val.dmac,
						acl_rule->cond.val.smac);

			ret = ies_acl_add_rule(sw, acl_tbl_index, acl_rule, &rule_index);
			if(ret != IES_OK)
			{
				debug_print("ies_acl_add_rule() for tbl_index %d failed. errno = %d\n", acl_tbl_index,ret);
				return;
			}
			debug_print("ACL rules created for tbl_index %d with rule id = %d\n", acl_tbl_index,rule_index);
			updateTestInfo_aclRules(acl_tbl_index,rule_index);
		}
	}
 
 }

static void create_acl(int sw, struct ies_acl_table_info *acl_tbl)
{
    int ret;

    acl_tbl->location = IES_ACL_FFU_GROUP_0;
    acl_tbl->acl_instance = IES_ACL_NO_INSTANCE;
    acl_tbl->scenario = IES_ACL_SCENARIO_INGRS_IPV4 |
                        IES_ACL_SCENARIO_INGRS_IPSEC_ESP_V4; 

    acl_tbl->condition = IES_ACL_MATCH_DIP |
                        IES_ACL_MATCH_SIP |
                        IES_ACL_MATCH_DMAC |
                        IES_ACL_MATCH_SMAC |
                        IES_ACL_MATCH_VLAN |
                        IES_ACL_MATCH_PROT |
                        IES_ACL_MATCH_METADATA |
                        IES_ACL_MATCH_SRC_LOGICAL_PORT;

    acl_tbl->mask.dmac = 0xffffffffffff;
    acl_tbl->mask.smac = 0xffffffffffff;
    acl_tbl->mask.protocol = 0xff;
    acl_tbl->mask.sip.is_ipv6 = true;
    acl_tbl->mask.sip.addr[0] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[1] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[2] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[3] = htonl(0xffffffff);
    acl_tbl->mask.dip.is_ipv6 = true;
    acl_tbl->mask.dip.addr[0] = 0xffffffff;
    acl_tbl->mask.dip.addr[1] = 0xffffffff;
    acl_tbl->mask.dip.addr[2] = 0xffffffff;
    acl_tbl->mask.dip.addr[3] = 0xffffffff;

	acl_tbl->mask.meta.sel |= IES_ACL_MATCH_L3_DOMAIN;
    acl_tbl->mask.meta.l3_domain = 0x3f;
    acl_tbl->mask.vlan_id = 0xffff;
	acl_tbl->mask.src_logical_port = 0xffff;

    acl_tbl->min_entries = 1;
	acl_tbl->max_entries = 128;

    ret = ies_acl_create_table(sw, acl_tbl_index, acl_tbl);
    if(ret != IES_OK)
    {
        debug_print("ies_acl_create_table() failed. errno = %d\n", ret);
        return;
    }
    debug_print("Created ACL table. Index = %d\n",acl_tbl_index);
	updateTestInfo_aclTbl(acl_tbl_index);
}

static void create_acl_e(int sw, struct ies_acl_table_info *acl_tbl)
{
    int ret;
	char buf[IES_ERROR_MAX_TEXT_SIZE]; 
	
	/* Create Egress Table */
    acl_tbl->location = IES_ACL_FFU_GROUP_2;
    acl_tbl->acl_instance = IES_ACL_NO_INSTANCE;

	acl_tbl->scenario = IES_ACL_SCENARIO_EGRS_DSI ;
    acl_tbl->condition = IES_ACL_MATCH_DIP |
                        IES_ACL_MATCH_SIP |
                        IES_ACL_MATCH_DMAC |
                        IES_ACL_MATCH_SMAC ;
      
    acl_tbl->mask.dmac = 0xffffffffffff;
    acl_tbl->mask.smac = 0xffffffffffff;
    acl_tbl->mask.protocol = 0xff;
    acl_tbl->mask.sip.is_ipv6 = true;
    acl_tbl->mask.sip.addr[0] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[1] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[2] = htonl(0xffffffff);
    acl_tbl->mask.sip.addr[3] = htonl(0xffffffff);
    acl_tbl->mask.dip.is_ipv6 = true;
    acl_tbl->mask.dip.addr[0] = 0xffffffff;
    acl_tbl->mask.dip.addr[1] = 0xffffffff;
    acl_tbl->mask.dip.addr[2] = 0xffffffff;
    acl_tbl->mask.dip.addr[3] = 0xffffffff;


    acl_tbl->min_entries = 1;
	acl_tbl->max_entries = 128;


    ret = ies_acl_create_table(sw, acl_tbl_index_e, acl_tbl);
    if(ret != IES_OK)
    {
		ies_error_get_text(ret, buf, sizeof(buf)); 
        debug_print("ies_acl_create_table() - Egress  failed. errno = %d %s \n", ret,buf);
        return;
    }
    debug_print("Created ACL table for Egress. Index = %d\n",acl_tbl_index_e);
	updateTestInfo_aclTbl(acl_tbl_index_e);
}

int setup_port_to_queue_mapping(void)
{
    int sw = 0;
     int ret, qid;
    struct ies_acl_table_info acl_tbl;
    struct ies_acl_rule_info acl_rule;

    unsigned int i;
    unsigned int val = 0;
    bool tag = true;
    bool attr_val = false;
	int port;
	
	char buf[IES_ERROR_MAX_TEXT_SIZE];

	
    for(i = 0; i < num_hlp_ports; i++)
    {
		if(!is_port_enabled(i))
		{
			continue;
		}
        ret = ies_port_set_attr(sw, i, IES_PA_LEARNING, &val);
        if(ret != IES_OK)
        {
            debug_print("ies_port_set_attr() failed. errorno = %d\n", ret);
            return -1;
        }
    }

    for(i = 0; i < num_hlp_ports; i++)
    {
		if(!is_port_enabled(i))
		{
			continue;
		}
        /*Set replace vlan fields to false*/
        ret = ies_port_set_attr(sw, i, IES_PA_REPLACE_VLAN_FIELDS, &attr_val);
        if(ret != IES_OK)
        {
            debug_print("ies_port_set_attr() failed. errorno = %d\n", ret);
            return -1;
        }
		

    }

#if 0
    /*Create vlan 1001*/
    ret = ies_vlan_create(sw, 1001);
    if(ret != IES_OK)
    {
        debug_print("ies_vlan_create() failed. errno = %d\n", ret);
        return -1;
    }
	updateTestInfo_vlan(1001);

    /*Add port 0 to VLAN-1001*/
    ret = ies_vlan_add_port(sw, 1001, 0, tag);
    if(ret != IES_OK)
    {
        debug_print("ies_vlan_add_port() failed. errno = %d\n", ret);
        return -1;
    }

    /*Add port 22 to VLAN-1001*/
    ret = ies_vlan_add_port(sw, 1001, 22, tag);
    if(ret != IES_OK)
    {
        debug_print("ies_vlan_add_port() failed. errno = %d\n", ret);
        return -1;
    }
#endif

    acl_tbl_index = 1;
	acl_tbl_index_e = 2;

    for(qid = 0; qid < (int) num_hlp_ports ; qid++)
    {
		if(!is_port_enabled(qid))
		{
			continue;
		}
        /*Get logical port number of vsi-qid tuple*/
        ret = ies_vsi_map_vsi_qid_to_port(sw, vsi_number, qid, &logical_port[qid]);
        if(ret != IES_OK)
        {
            debug_print("vsi_qid_to_port_map() failed. errorno = %d\n", ret);
            return -1;
        }
        debug_print("Logical ports %d\n", logical_port[qid]);
    }

    /*Set default destination ports for all ingress ports to logical ports acquired earlier*/
    
    for(port = 0; port < (int)num_hlp_ports; port++)
    {
		if(!is_port_enabled(port))
		{
			continue;
		}
        debug_print("Ingress port %d ... logical port %d\n", port, logical_port[port]);

        ret = ies_port_set_attr(sw, port, IES_PA_DEF_DEST_PORT, &logical_port[port]);
        if(ret != IES_OK)
        {
            debug_print("ies_port_set_attr() failed. errorno = %d\n", ret);
            return -1;
        }
    }

	int attr_parser = 0;
		
	/*Disable DROP_PARSER so packets will not be dropped if there is a parser error after CPM encrypts a packet */
	ret = ies_port_set_attr(sw, 22, IES_PA_DROP_PARSER_ERR, &attr_parser);
	if(ret != IES_OK)
	{
		ies_error_get_text(ret, buf, sizeof(buf)); 
		debug_print("ies_port_set_attr(IES_PA_DROP_PARSER_ERR) failed. errorno = %d %s\n", ret,buf);
	}

    /*Setup acl tables, rules. Redirect packets to logical ports by matching rules*/
    memset(&acl_tbl, 0, sizeof(acl_tbl));
    create_acl(sw, &acl_tbl);

    /*Add rules to ACL table*/
    memset(&acl_rule, 0, sizeof(acl_rule));
	add_rules(sw, &acl_rule);
	
	if(qat_order)
	{
		ret = ies_trigger_alloc_resources(sw, IES_TRIGGER_RES_FFU,&acl_trig_id);
		if(ret != IES_OK)
		{
			ies_error_get_text(ret, buf, sizeof(buf)); 
			debug_print("ies_trigger_alloc_resources() failed. errorno = %d %s\n", ret,buf);
			acl_trig_id = -1;
		}
		else
		{	
			debug_print("Allocated trigger id = %d for FFU/ACL Trigger\n", acl_trig_id);
			updateTestInfo_resource(IES_TRIGGER_RES_FFU,acl_trig_id);
#if 1			
			/*setup egress ACL table*/
			memset(&acl_tbl, 0, sizeof(acl_tbl));
			create_acl_e(sw, &acl_tbl);
		
			/*Add egress rules to egress ACL table*/
			memset(&acl_rule, 0, sizeof(acl_rule));
			add_rules_e(sw, &acl_rule);
#endif
			ret = ies_ipsec_enable_ordering(sw, acl_trig_id);
			if(ret != IES_OK)
			{
				ies_error_get_text(ret, buf, sizeof(buf)); 
				debug_print("ies_ipsec_enable_ordering() failed. errorno = %d %s\n", ret,buf);
			}
		}
	}
	

    return 0;
}


