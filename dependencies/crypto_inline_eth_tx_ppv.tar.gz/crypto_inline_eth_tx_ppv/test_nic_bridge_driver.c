/*-
 *   BSD LICENSE
 *
 *   Copyright(c) 2016 Intel Corporation. All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "main.h"
#include "lib_socket.h"
#include <ice_dsi_ipsec.h>

extern bool qat_order;
//#define FRIO_DEBUG
#define RX_BURST_SIZE 64
#define TX_NSEC		1000


uint64_t   dmac = 0xDEADBEEF0001;
uint64_t   smac = 0x000A01010101;

unsigned char pdu_buffer[] = {
0x40,0x41,0x42,0x43,0x44,0x45,
0x46,0x47,0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x45,0x00,0x00,0xA8,0x04,0xC6,
0x00,0x00,0x08,0x06,0x85,0x70,0x0A,0x0A,0x0A,0x01,0x0A,0x0A,0x0A,0x06,0x05,0xDC,
0x06,0x40,0x00,0x00,0x03,0xE9,0x00,0x00,0x00,0x00,0x50,0x20,0x00,0x00,0xB5,0x23,
0x00,0x00,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,
0x0E,0x0F,0x01,0x02,0x03,0x04,0x05,0x06,0x06,0x04,0x1F,0x9D,0x28,0x2D,0x55,0x1E,
0xC0,0x02,0xD4,0x52,0xEB,0x38};
unsigned char pdu_buffer_1[] = {
0x40,0x41,0x42,0x43,0x44,0x45,
0x46,0x47,0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x45,0x00,0x00,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,0xA5,
0xA5,0xA5,0x01,0x02,0x03,0x04,0x05,0x06,0x06,0x04,0x1F,0x9D,0x28,0x2D,0x55,0x1E,
0xC0,0x02,0xD4,0x52,0xEB,0x38};
int data_len = 188;

extern int destPort;
extern int num_rxq_per_port;
extern int num_txq_per_port;
extern bool egress_encrypt;
extern int rx_only;
extern unsigned int  pkt_len;
extern unsigned int tx_burst_len;


#ifndef STATS_64
extern uint32_t tx_drop_packets_qid[];
extern uint32_t tx_wred_drop_packets_qid[];
extern uint32_t cp_packets_qid[];
extern uint32_t sa_error_qid[];
#else
extern uint64_t tx_drop_packets_qid[];
extern uint64_t tx_wred_drop_packets_qid[];
extern uint64_t cp_packets_qid[];
extern uint64_t sa_error_qid[];
#endif



void print_drop_stats_q(uint32_t qid)
{
	if(tx_drop_packets_qid[qid] || tx_wred_drop_packets_qid[qid] )
	{
#ifndef STATS_64
		debug_print("tx_drop_packets[%d]:%d  tx_wred_drop_packets[%d]:%d\n", qid,tx_drop_packets_qid[qid],qid,tx_wred_drop_packets_qid[qid]);
#else
		debug_print("tx_drop_packets[%d]:%lu  tx_wred_drop_packets[%d]:%lu\n", qid,tx_drop_packets_qid[qid],qid,tx_wred_drop_packets_qid[qid]);
#endif
	}
}


void print_cpq_stats_q(uint32_t qid)
{
	if(cp_packets_qid[qid])
	{
#ifndef STATS_64
		debug_print("cp_packets[%d]:%d\n", qid,cp_packets_qid[qid]);
#else
		debug_print("cp_packets[%d]:%lu\n", qid,cp_packets_qid[qid]);
#endif
	}
}

void print_sa_error_stats_q(uint32_t qid)
{
	if(sa_error_qid[qid])
	{
#ifndef STATS_64
		debug_print("sa_error_packets[%d]:%d\n", qid,sa_error_qid[qid]);
#else
		debug_print("sa_error_packets[%d]:%lu\n", qid,sa_error_qid[qid]);
#endif
	}
}
#define NUM_TX_RETRIES 2
#define WRED_COLOR	RTE_TM_GREEN

int completion_queue_thread(void *arg)
{
	uint32_t num_cp_pkts = 10 * num_hlp_ports * RX_BURST_SIZE;
	/*For completion queue*/
    struct rte_eth_cp_pkt pkts[num_cp_pkts];
	uint32_t num;
	
	uint32_t eth_port_id = 0;
	
	RTE_SET_USED(arg);
	
	debug_print("Starting completion_queue_thread \n");
	while (!test_done_v)
	{
		num = 0;
		
		/* Call rte_eth_cp_burst() to verify completions */
		/* There is one CQ for all TxQueues in a VDEV so try to dequeue and free as many as possible */
		num = rte_eth_cp_burst(eth_port_id, 0, pkts, num_cp_pkts);
		cp_packets_qid[0] += num;
	}
	debug_print("Exiting completion_queue_thread - test_done %d\n",test_done_v);
	print_cpq_stats_q(0);
	return 0;
}
/**
 * @brief Function to sleep/yield nanoseconds.
 *        Function calls all but last 2us from rte_delay_us_block(),
 *        then spin waits for remaining time.
 *
 * @param nsecs
 *     Sleep time in nanoseconds.
 *
 * @return None
 *
 */
inline void l_nano_sleep( long requested_nsecs );
inline void
l_nano_sleep( long requested_nsecs )
{
    struct  timespec ts;    // used for current and wake times.
    long    nsecs_end, nsecs_now;
    // fetch current time.
    clock_gettime( CLOCK_REALTIME, &ts );
    nsecs_end = ts.tv_sec * 1E9L + ts.tv_nsec + requested_nsecs;
    do {
        pthread_yield();
        clock_gettime( CLOCK_REALTIME, &ts );
        nsecs_now = ts.tv_sec * 1E9L + ts.tv_nsec;
    } while( nsecs_end > nsecs_now );
}

int nic_monitor_rx(void *arg)
{
	RTE_SET_USED(arg);

    uint32_t qid, eth_port_id, rx = 0;
	uint32_t *arg_ptr;
	uint32_t port_num,start_qid,end_qid;
#ifdef FRIO_DEBUG
    uint8_t *buf_addr;
#endif
    struct rte_mbuf *mbufs[RX_BURST_SIZE];
    struct rte_mbuf *m;
    uint32_t i;
	uint32_t rx_off,tx_off;
	struct ice_dsi_rx_metadata *dsi_meta;
	
#ifdef FRIO_DEBUG
    struct ice_dsi_crypto_session *crypto_sess;
    struct rte_eth_dev_info dev_info;
	struct sadb_sa_idx_table
	{
       uint32_t sa_idx_in;
	   uint32_t sa_idx_out;
	   uint32_t	trailer_len;
	};
	struct	sadb_sa_idx_table	sa_idx_table[NUM_SESSIONS_PER_DEV/2];
	int sa_index_pair_count = 0;
#endif	

	debug_print("%s NUM_SESSIONS_PER_DEV %d\n",__FILE__,NUM_SESSIONS_PER_DEV);

	/* Get hlp_Port_num that is passed in as an argument to the thread */
	arg_ptr = (uint32_t *) arg;
	port_num = *arg_ptr;
	eth_port_id = 0;
	start_qid = port_num * num_rxq_per_port;
	end_qid = start_qid + num_rxq_per_port;

#ifdef FRIO_DEBUG
   /*Get the sa_idx and trailer length from crypto_session struct*/
    rte_eth_dev_info_get(eth_port_id, &dev_info);
	for (k=0;k<NUM_SESSIONS_PER_DEV;k++)
	{
	    crypto_sess = (struct ice_dsi_crypto_session *)(cparams[k].session->sess_private_data);
		if(crypto_sess == NULL)
		{
			debug_print("crypto_sess is NULL exiting loop\n");
			break;
		}
		if (crypto_sess->sa_idx == 0)
		{
			debug_print("crypto_sess sa_idx is 0 exiting loop\n");
			break;
		}
        debug_print("crypto_sess %d = 0x%lx\n", k,(unsigned long)crypto_sess);
        debug_print("sa_idx %d = %d\n", k,crypto_sess->sa_idx);
#if (RTE_VER_YEAR == 18 && RTE_VER_MONTH==05)
        debug_print("trailer_len %d = %d\n", k,crypto_sess->trailer_len);
#endif
		if((k%2) == 0)
		{	
			sa_idx_table[sa_index_pair_count].sa_idx_in = crypto_sess->sa_idx;
#if (RTE_VER_YEAR == 18 && RTE_VER_MONTH==05)
			sa_idx_table[sa_index_pair_count].trailer_len = crypto_sess->trailer_len;
#else
			sa_idx_table[sa_index_pair_count].trailer_len = 0;
#endif
		}
		else
		{
			sa_idx_table[sa_index_pair_count].sa_idx_out = crypto_sess->sa_idx;
			sa_index_pair_count++;
		}
	}
	
	for (k=0;k<NUM_SESSIONS_PER_DEV/2 ;k++)
	{
		debug_print("sa_pair %d sa_idx_in = %d sa_idx_out = %d trailer_len = %d\n", k,sa_idx_table[k].sa_idx_in,sa_idx_table[k].sa_idx_out,sa_idx_table[k].trailer_len);
	}
#endif
	
	debug_print("RX burst size is %d\n", RX_BURST_SIZE);
	debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
	
	debug_print("Entering while loop... for vdev %d port %d start_qid %d num_rxqs %d\n",eth_port_id,port_num, start_qid,num_rxq_per_port);
	
	rte_pmd_ice_dsi_get_metadata_offset(0, &rx_off, &tx_off);
	while(!test_done_v)
    {
		if(curr_port_num_rx[port_num] != port_num)
		{
			int changed_port_num = curr_port_num_rx[port_num];
			start_qid = changed_port_num * num_rxq_per_port;
			end_qid = start_qid + num_rxq_per_port;
			curr_port_num_rx[changed_port_num] = changed_port_num;
			curr_port_num_rx[port_num] = port_num;
			debug_print("Switching Rx from Port  %d to Port %d using start_qid %d end_qid %d\n",port_num,changed_port_num,start_qid,end_qid);
			port_num = changed_port_num;
		}
		if(in_reset)
		{
			sleep(2);
			continue;
		}
		for(qid = start_qid; qid < end_qid; qid++)
        {
            i = 0;
            rx = rte_eth_rx_burst(eth_port_id, qid, mbufs, RX_BURST_SIZE);
			if(!rx)
			{
				continue;
			}
#ifdef FRIO_DEBUG
            debug_print("rx = %d\n", rx);
#endif
			rx_packets_qid[qid] += rx;
			
			while(i < rx)
            {
#ifdef PRINT_RT_STATS
               /*If packets are received. check  metadata and free them*/
				if(((rx_packets_qid[qid] % NUM_BD_PKTS) == 0) && (rx_packets_qid[qid] != 0))
				{
					print_stats_q(qid);
				}
#endif
				m = mbufs[i];		
				dsi_meta = rte_ice_dsi_mbuf_rx_meta(m, rx_off);
				if(dsi_meta->ipsec_offloaded && dsi_meta->ipsec_status != 0)
				{
					sa_error_qid[qid]++;
				}
				uint32_t data_offset;
				unsigned char *data_addr;
				data_offset = sizeof(struct ether_hdr) + sizeof(struct ipv4_hdr) + 8;
				data_addr = (unsigned char *)(rte_pktmbuf_mtod(m, char *) + data_offset);
				if(memcmp(data_addr,pdu_buffer,data_len))
				{
					//debug_print("decryption buffer compare failed\n");
					sa_error_qid[qid]++;
				}
#ifdef FRIO_DEBUG				
				debug_print("m->pkt_len %d\n",m->pkt_len);
				debug_print("m->data_len %d\n", m->data_len);
				debug_print("m->buf_len %d\n",m->buf_len );
				debug_print("m->priv_size %d\n",m->priv_size);
				debug_print("m->data_off %d\n",m->data_off);				
				err = rte_pmd_ice_dsi_get_metadata_offset(0, &rx_off, &tx_off);
  
                dsi_meta = rte_ice_dsi_mbuf_rx_meta(m, rx_off);
                debug_print("ipsec_offloaded = %d\n", dsi_meta->ipsec_offloaded);
                debug_print("sa_id = %d\n", dsi_meta->sa_idx);
				debug_print("ipsec_status = %d\n", dsi_meta->ipsec_status);
				
	struct ether_hdr *eth_hdr;				
	struct ipv4_hdr *ip_hdr;
	uint32_t ip_offset;
    eth_hdr = rte_pktmbuf_mtod(m, struct ether_hdr *);
	debug_print("eth_hdr->s_addr 0x%x eth_hdr->d_addr 0x%x\n", eth_hdr->s_addr,eth_hdr->d_addr);
    ip_offset = sizeof(struct ether_hdr);
    ip_hdr = (struct ipv4_hdr *)(rte_pktmbuf_mtod(m, char *) + ip_offset);
	debug_print("ip_hdr->src_addr 0x%x ip_hdr->dst_addr 0x%x\n", ip_hdr->src_addr,ip_hdr->dst_addr);
	debug_print("eth_hdr->ether_type %d %d\n",eth_hdr->ether_type,rte_cpu_to_be_16(ETHER_TYPE_IPv4));
	buf_addr = (uint8_t *)m->buf_addr + m->data_off;
    rte_hexdump(stdout, "RX Mbuf", (const void *)buf_addr, m->data_len);
#endif
				rte_pktmbuf_free(m);
				i++;
			}
			total_packets += rx;
		}
	}
	debug_print("Exiting nic_monitor_rx - Port %d - test_done %d\n",port_num,test_done_v);
	for(qid = start_qid; qid < end_qid; qid++)
	{
		print_stats_q(qid);
		print_sa_error_stats_q(qid);
	}
	return 0;
}



int nic_monitor_tx(void *arg)
{
	RTE_SET_USED(arg);
	int err;
    uint32_t qid, eth_port_id, tx = 0;
	uint32_t *arg_ptr;
	uint32_t port_num,start_qid,end_qid;
	
	uint32_t multi_retries = tx_burst_len * NUM_TX_RETRIES;
	
    uint8_t *buf_addr;

    struct rte_mbuf *mbufs[2*tx_burst_len];
    struct rte_mbuf *m;
    struct ice_dsi_tx_metadata *dsi_tx_meta;
	
    struct ice_dsi_crypto_session *crypto_sess;
    struct rte_eth_dev_info dev_info;
	
    uint32_t rx_off,tx_off, i, num, retry;

	uint32_t k;
    struct sadb_sa_idx_table
	{
       uint32_t sa_idx_in;
	   uint32_t sa_idx_out;
	   uint32_t	trailer_len;
	};
	
	struct	sadb_sa_idx_table	sa_idx_table[NUM_SESSIONS_PER_DEV/2];
	int sa_index_pair_count = 0;
	
	/*For completion queue*/
	uint32_t num_cp_pkts = 10 * tx_burst_len;
	struct rte_eth_cp_pkt pkts[num_cp_pkts];
	
	struct ether_hdr *eth_hdr;				
	struct ipv4_hdr *ip_hdr;
	uint32_t ip_offset;
	uint32_t data_offset;
	unsigned char *data_addr;
	int offset = 0;
	
	unsigned long long  payld_rate;
	uint32_t port_rate;
	int dly_calc,dly_used,pkts_per_sec;
	long 	nsecs_tx_burst = 0;
	uint32_t num_mbufs = num_txq_per_port * 2 *tx_burst_len;
	
	debug_print("%s NUM_SESSIONS_PER_DEV %d\n",__FILE__,NUM_SESSIONS_PER_DEV);

	/* Get hlp_Port_num that is passed in as an argument to the thread */
	arg_ptr = (uint32_t *) arg;
	port_num = *arg_ptr;
	eth_port_id = 0;
	start_qid = port_num * num_txq_per_port;
	end_qid = start_qid + num_txq_per_port;
	
	if(egress_encrypt)
	{
	  /*Get the sa_idx and trailer length from crypto_session struct*/
		rte_eth_dev_info_get(eth_port_id, &dev_info);
		for (k=0;k<NUM_SESSIONS_PER_DEV;k++)
		{
			crypto_sess = (struct ice_dsi_crypto_session *)(cparams[k].session->sess_private_data);
			if(crypto_sess == NULL)
			{
				debug_print("crypto_sess is NULL exiting loop\n");
				break;
			}
			if (crypto_sess->sa_idx == 0)
			{
				debug_print("crypto_sess sa_idx is 0 exiting loop\n");
				break;
			}
			debug_print("crypto_sess %d = 0x%lx\n", k,(unsigned long)crypto_sess);
			debug_print("sa_idx %d = %d\n", k,crypto_sess->sa_idx);
#if (RTE_VER_YEAR == 18 && RTE_VER_MONTH==05)
			debug_print("trailer_len %d = %d\n", k,crypto_sess->trailer_len);
#else
			debug_print("ivlen %d = %d\n", k,crypto_sess->ivlen);
#endif
			if((k%2) == 0)
			{	
				sa_idx_table[sa_index_pair_count].sa_idx_in = crypto_sess->sa_idx;
#if (RTE_VER_YEAR == 18 && RTE_VER_MONTH==05)
				sa_idx_table[sa_index_pair_count].trailer_len = crypto_sess->trailer_len;
#else
				sa_idx_table[sa_index_pair_count].trailer_len = crypto_sess->ivlen;
#endif
			}
			else
			{
				sa_idx_table[sa_index_pair_count].sa_idx_out = crypto_sess->sa_idx;
				sa_index_pair_count++;
			}
		}
	
		for (k=0;k<NUM_SESSIONS_PER_DEV/2 ;k++)
		{
			debug_print("sa_pair %d sa_idx_in = %d sa_idx_out = %d trailer_len = %d\n", k,sa_idx_table[k].sa_idx_in,sa_idx_table[k].sa_idx_out,sa_idx_table[k].trailer_len);
		}
	}
	tx = tx_burst_len;
	
	debug_print("TX burst size is %d\n", tx_burst_len);
	
#ifdef MBUF_TX
	debug_print("Using seperate MPOOL for TX\n");
	err = rte_pktmbuf_alloc_bulk( mp_nic_tx, &mbufs[0], num_mbufs);
	if (err )
	{
		debug_print("Exiting nic_monitor_tx \n");
		debug_print("producer thread failed to alloc mbuf from cpu pool %d\n",err);
		debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic_tx));
		return -1;
	}
#else
	err = rte_pktmbuf_alloc_bulk( mp_nic, &mbufs[0], num_mbufs);
	if (err )
	{
		debug_print("Exiting nic_monitor_tx \n");
		debug_print("producer thread failed to alloc mbuf from cpu pool %d\n",err);
		debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
		return -1;
	}
#endif

	for(i=0;i<num_mbufs;i++)
	{
		m = mbufs[i];
		m->pkt_len = pkt_len - 4;
		m->data_len = m->pkt_len;
		m->buf_len = RTE_MBUF_DEFAULT_BUF_SIZE;
		m->priv_size = priv_size;
		m->data_off = 128;
			
		m->nb_segs = 1; /*nb_rx;*/
		m->ol_flags |= PKT_TX_METADATA;

#ifndef RDK2010		
		/* Pass TM Color in lower byte of sched */
		m->hash.sched.lo = WRED_COLOR;
#else
		m->hash.sched.color = WRED_COLOR;
#endif

        err = rte_pmd_ice_dsi_get_metadata_offset(0, &rx_off, &tx_off);
        if(err < 0)
            debug_print("Error in rte_pmd_ice_dsi_get_metadata_offset(). errno = %d\n", err);
#ifdef FRIO_DEBUG
        debug_print("rx_off = %d...tx_off = %d\n", rx_off, tx_off);
#endif

        dsi_tx_meta = rte_ice_dsi_mbuf_tx_meta(m, tx_off);
        memset(dsi_tx_meta, 0, sizeof(struct ice_dsi_tx_metadata));

        /*Set tx metadata fields*/
        dsi_tx_meta->overwrite = 1;
        dsi_tx_meta->dst_port = port_num;
        dsi_tx_meta->tc = i%8;
        dsi_tx_meta->lag_hash = 0;
		if(egress_encrypt)
		{
            /*Update metadata for ipsec*/
            dsi_tx_meta->extended_seq_id = 1;
			if(!qat_order)
			{
				dsi_tx_meta->sa_id = sa_idx_table[0].sa_idx_out;
				dsi_tx_meta->trailer_len = sa_idx_table[0].trailer_len;
				//dsi_tx_meta->ipsec_offload = 1; //DPDK 10/28/2019 'struct ice_dsi_tx_metadata’ has no member named ‘ipsec_offload’
				m->ol_flags |= PKT_TX_SEC_OFFLOAD;  //Needed for DPDK 04062018
			}
		}

#ifdef FRIO_DEBUG		
		debug_print("dsi_tx_meta->sa_id %d ipsec_offload %d \n", dsi_tx_meta->sa_id,dsi_tx_meta->ipsec_offload);
#endif

        buf_addr = (uint8_t *)m->buf_addr + m->data_off;
		buf_addr[5]= (dmac && 0xFF);
		buf_addr[4]= (dmac >> 8);
		buf_addr[3]= (dmac >> 16);
		buf_addr[2]= (dmac >> 24);
		buf_addr[1]= (dmac >> 32);
		buf_addr[0]= (dmac >> 40);
		buf_addr[11]= (dmac && 0xFF);
		buf_addr[10]= (dmac >> 8);
		buf_addr[9]= (dmac >> 16);
		buf_addr[8]= (dmac >> 24);
		buf_addr[7]= (dmac >> 32);
		buf_addr[6]= (dmac >> 40);

		buf_addr[14]=0x45;
		buf_addr[15]=0;
		buf_addr[16]=0;
		buf_addr[17]=0xE8;
		eth_hdr = rte_pktmbuf_mtod(m, struct ether_hdr *);
#ifdef FRIO_DEBUG
		debug_print("eth_hdr->s_addr 0x%x eth_hdr->d_addr 0x%x\n", eth_hdr->s_addr,eth_hdr->d_addr);
#endif
		eth_hdr->ether_type = rte_cpu_to_be_16(ETHER_TYPE_IPv4);
		ip_offset = sizeof(struct ether_hdr);
		ip_hdr = (struct ipv4_hdr *)(rte_pktmbuf_mtod(m, char *) + ip_offset);
#ifdef FRIO_DEBUG
		debug_print("ip_hdr->src_addr 0x%x ip_hdr->dst_addr 0x%x\n", ip_hdr->src_addr,ip_hdr->dst_addr);
#endif
		ip_hdr->src_addr = 0x500a8c0;
		ip_hdr->dst_addr = 0x1020214;
		if(egress_encrypt)
		{
			ip_hdr->next_proto_id = 50;
			ip_hdr->hdr_checksum = 0;
			//B0 fix
			m->ol_flags |= PKT_TX_IP_CKSUM; 		//Temp workaround until DPDK is fixed
			m->l2_len = sizeof(struct ether_hdr);
			m->ol_flags |= PKT_TX_IPV4;
			m->l3_len = sizeof(struct ipv4_hdr);
		}
		else
		{
			ip_hdr->next_proto_id = 6;
			ip_hdr->hdr_checksum = rte_ipv4_cksum(ip_hdr);
		}
		//ip_hdr->hdr_checksum = rte_ipv4_cksum(ip_hdr);
#ifdef FRIO_DEBUG
		debug_print("eth_hdr->s_addr 0x%x eth_hdr->d_addr 0x%x\n", eth_hdr->s_addr,eth_hdr->d_addr);
		debug_print("ip_hdr->src_addr 0x%x ip_hdr->dst_addr 0x%x\n", ip_hdr->src_addr,ip_hdr->dst_addr);
#endif
		data_offset = sizeof(struct ether_hdr) + sizeof(struct ipv4_hdr) + 8;
		data_addr = (unsigned char *)(rte_pktmbuf_mtod(m, char *) + data_offset);
		// copy clear data to mbuf
		rte_memcpy(data_addr, pdu_buffer, data_len);
		//rte_memcpy(data_addr, pdu_buffer_1, data_len);
#ifdef FRIO_DEBUG
        rte_hexdump(stdout, "TX Mbuf", (const void *)buf_addr, m->data_len);
#endif
	}
	
	
	port_rate = port_speed[port_num] ;
	nsecs_tx_burst = 1950;

	if(egress_encrypt && !qat_order)
	{
		nsecs_tx_burst = 2025;
	}
	
	payld_rate = ((unsigned long long )(port_rate) *  1000000000LL); 

	if( port_rate == 2)
	{
		payld_rate = ((unsigned long long )(5) *  1000000000LL)/2;
	}

	// Num of bursts per second required to hit requested bit rate
	pkts_per_sec = payld_rate/(pkt_len * tx_burst_len * 8);
	
	// Convert seconds to nanoseconds between packets required to meet BW.
    dly_calc = 1E9L / pkts_per_sec;
	dly_used = dly_calc - nsecs_tx_burst;
	
	if(port_rate > 25)
		dly_used = 0;

	debug_print("port_speed[%d] %d payld_rate %llu pkts_per_sec %d dly_calc %d\n",port_num,port_rate,payld_rate, pkts_per_sec,dly_calc);
	
	debug_print("Entering while loop...\n");
	debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
	debug_print("Starting Tx Loop - <ctrl-c> to exit on qid %d - \n",start_qid);
	
	while(!test_done_v)
    {
		if(curr_port_num_tx[port_num] != port_num)
		{
			int changed_port_num = curr_port_num_tx[port_num];
			uint32_t rx_off,tx_off;
			struct ice_dsi_tx_metadata *dsi_tx_meta; 
			
			rte_pmd_ice_dsi_get_metadata_offset(0, &rx_off, &tx_off);
			
			start_qid = changed_port_num * num_txq_per_port;
			end_qid = start_qid + num_txq_per_port;
			curr_port_num_tx[changed_port_num] = changed_port_num;
			curr_port_num_tx[port_num] = port_num;
			debug_print("Switching Tx from Port %d to Port %d using start_qid %d end_qid %d\n",port_num,changed_port_num,start_qid,end_qid);
			port_num = changed_port_num;
			for(int i=0;i< num_mbufs;i++)
			{
				dsi_tx_meta = rte_ice_dsi_mbuf_tx_meta(mbufs[i], tx_off);
               /*Set tx metadata fields*/
       	
				if(destPort != 99)
				{
					dsi_tx_meta->dst_port = destPort;
				}
				else
				{
					dsi_tx_meta->dst_port = port_num;
				}
			}
		}	
		if(in_reset)
		{
			sleep(2);
			continue;
		}

		if(port_flags[port_num] == 0)
		{
			continue;
		}
		
        for(qid = start_qid; qid < end_qid; qid++)
        {
			num = 0;
			retry = 0;
			tx = 0;

			do
			{
				num = rte_eth_tx_burst(eth_port_id, qid, &mbufs[tx+offset], tx_burst_len - tx);
				for(i=0;i<num;i++)
				{
					/* free mbuf if rte_eth_tx_burst transmitted but WRED dropped the mbuf */		
					if (rte_pktmbuf_tx_enqueue_status(mbufs[tx+offset+i]) == RTE_MBUF_TX_ENQUEUE_WRED_DROP)
					{
							tx_wred_drop_packets_qid[qid]++;
					}
					else
					{
						tx_packets_qid[qid]++;
					}
				}
				tx += num;
#ifdef FRIO_DEBUG
				if ((tx_burst_len-tx > 0) && (num > 0))
					debug_print("rx-tx = %d..num = %d..retry = %d\n", tx_burst_len-tx, num, retry); 
#endif
			}while((tx != tx_burst_len) && (retry++ < multi_retries));
			if (retry >= multi_retries)
			{
				tx_drop_packets_qid[qid]+= (tx_burst_len-tx);
			}

			/* DO completion in tx thread if 1 cpq per 1 txq */
			if (!seperate_thread_completion)
			{
				num = 0;
				/* Call rte_eth_cp_burst() to verify completions */
				/* There is one CQ per TxQueues  dequeue and free as many as possible */
				num = rte_eth_cp_burst(eth_port_id, qid, pkts, num_cp_pkts);
				cp_packets_qid[qid] += num;
			}
			if(offset == 0)
				offset = tx_burst_len;
			else
				offset = 0;
#ifdef PRINT_RT_STATS
			if(((tx_packets_qid[qid] % NUM_BD_PKTS) == 0) && (tx_packets_qid[qid] != 0))
			{
				print_stats_q(qid);
				print_drop_stats_q(qid);
			}
#endif
	
			/* wait for dly_used nano seconds */
			if(dly_used)
				l_nano_sleep(dly_used);
		}	
	}

	debug_print("Exiting nic_monitor_tx - Port %d  test_done %d\n",port_num,test_done_v);
	debug_print("port_num %d nsecs_tx_burst %lu dly_used %d\n",port_num,nsecs_tx_burst,dly_used);
	for(qid = start_qid; qid < end_qid; qid++)
	{
		print_stats_q(qid);
		if (!seperate_thread_completion)
		{
			print_cpq_stats_q(qid);
		}
		print_drop_stats_q(qid);	
		print_txqueue_tm_stats(eth_port_id, qid );
	}
	return 0;
}

int start_snake_traffic(int snake_start_port)
{
    uint8_t *buf_addr;

    struct rte_mbuf *mbufs[512];
    struct rte_mbuf *m;
    struct ice_dsi_tx_metadata *dsi_tx_meta;
	
    struct rte_eth_dev_info dev_info;
	uint32_t rx_off,tx_off, i, num;
	struct ether_hdr *eth_hdr;				
	struct ipv4_hdr *ip_hdr;
	uint32_t ip_offset;
	uint32_t data_offset;
	unsigned char *data_addr;
	int offset = 0;
	int eth_port_id = 0;
	char cliCmd[128];
	
	struct rte_eth_cp_pkt pkts[512];
	int err;
	
	err = rte_pktmbuf_alloc_bulk( mp_nic, &mbufs[0], 512);
	if (err )
	{
		debug_print("Exiting nic_monitor_tx \n");
		debug_print("producer thread failed to alloc mbuf from cpu pool %d\n",err);
		debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
		return -1;
	}

	for(i=0;i<512;i++)
	{
		m = mbufs[i];
		m->pkt_len = pkt_len - 4;
		m->data_len = m->pkt_len;
		m->buf_len = RTE_MBUF_DEFAULT_BUF_SIZE;
		m->priv_size = priv_size;
		m->data_off = 128;
			
		m->nb_segs = 1; /*nb_rx;*/
		m->ol_flags |= PKT_TX_METADATA;

#ifndef RDK2010		
		/* Pass TM Color in lower byte of sched */
		m->hash.sched.lo = WRED_COLOR;
#else
		m->hash.sched.color = WRED_COLOR;
#endif

        err = rte_pmd_ice_dsi_get_metadata_offset(0, &rx_off, &tx_off);
        if(err < 0)
            debug_print("Error in rte_pmd_ice_dsi_get_metadata_offset(). errno = %d\n", err);
#ifdef FRIO_DEBUG
        debug_print("rx_off = %d...tx_off = %d\n", rx_off, tx_off);
#endif

        dsi_tx_meta = rte_ice_dsi_mbuf_tx_meta(m, tx_off);
        memset(dsi_tx_meta, 0, sizeof(struct ice_dsi_tx_metadata));

        /*Set tx metadata fields*/
        dsi_tx_meta->overwrite = 1;
        dsi_tx_meta->dst_port = snake_start_port;
         dsi_tx_meta->tc = i%8;
        dsi_tx_meta->lag_hash = 0;


#ifdef FRIO_DEBUG		
		debug_print("dsi_tx_meta->sa_id %d ipsec_offload %d \n", dsi_tx_meta->sa_id,dsi_tx_meta->ipsec_offload);
#endif

        buf_addr = (uint8_t *)m->buf_addr + m->data_off;
		buf_addr[5]= (dmac && 0xFF);
		buf_addr[4]= (dmac >> 8);
		buf_addr[3]= (dmac >> 16);
		buf_addr[2]= (dmac >> 24);
		buf_addr[1]= (dmac >> 32);
		buf_addr[0]= (dmac >> 40);
		buf_addr[11]= (dmac && 0xFF);
		buf_addr[10]= (dmac >> 8);
		buf_addr[9]= (dmac >> 16);
		buf_addr[8]= (dmac >> 24);
		buf_addr[7]= (dmac >> 32);
		buf_addr[6]= (dmac >> 40);

		buf_addr[14]=0x45;
		buf_addr[15]=0;
		buf_addr[16]=0;
		buf_addr[17]=0xE8;
		eth_hdr = rte_pktmbuf_mtod(m, struct ether_hdr *);
#ifdef FRIO_DEBUG
		debug_print("eth_hdr->s_addr 0x%x eth_hdr->d_addr 0x%x\n", eth_hdr->s_addr,eth_hdr->d_addr);
#endif
		eth_hdr->ether_type = rte_cpu_to_be_16(ETHER_TYPE_IPv4);
		ip_offset = sizeof(struct ether_hdr);
		ip_hdr = (struct ipv4_hdr *)(rte_pktmbuf_mtod(m, char *) + ip_offset);
#ifdef FRIO_DEBUG
		debug_print("ip_hdr->src_addr 0x%x ip_hdr->dst_addr 0x%x\n", ip_hdr->src_addr,ip_hdr->dst_addr);
#endif
		ip_hdr->src_addr = 0x500a8c0;
		ip_hdr->dst_addr = 0x1020214;
		ip_hdr->next_proto_id = 6;
		ip_hdr->hdr_checksum = rte_ipv4_cksum(ip_hdr);
#ifdef FRIO_DEBUG
		debug_print("eth_hdr->s_addr 0x%x eth_hdr->d_addr 0x%x\n", eth_hdr->s_addr,eth_hdr->d_addr);
		debug_print("ip_hdr->src_addr 0x%x ip_hdr->dst_addr 0x%x\n", ip_hdr->src_addr,ip_hdr->dst_addr);
#endif
		data_offset = sizeof(struct ether_hdr) + sizeof(struct ipv4_hdr) + 8;
		data_addr = (unsigned char *)(rte_pktmbuf_mtod(m, char *) + data_offset);
		// copy clear data to mbuf
		rte_memcpy(data_addr, pdu_buffer, data_len);
#ifdef FRIO_DEBUG
        rte_hexdump(stdout, "TX Mbuf", (const void *)buf_addr, m->data_len);
#endif
	}
	

	num = rte_eth_tx_burst(eth_port_id, snake_start_port, &mbufs[0], 512);
	debug_print("Transmitted %d packets to Snake start port %d", num,snake_start_port);
	/* DO completion in tx thread if 1 cpq per 1 txq */
	if (!seperate_thread_completion)
	{
		num = 0;
		/* Call rte_eth_cp_burst() to verify completions */
		/* There is one CQ per TxQueues  dequeue and free as many as possible */
		num = rte_eth_cp_burst(eth_port_id, snake_start_port, pkts, 512);
	}

	sprintf(cliCmd,"reset port stats 20");
	ies_cli_exec_command(cliCmd, strlen(cliCmd), printf);
	
	return err;
}