/*-
 *   BSD LICENSE
 *
 *   Copyright(c) 2016 Intel Corporation. All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "main.h"
#include "common.h"

static void set_cipher_params(uint32_t session_id)
{
    switch (session_id)
    {
        case 0:
        case 1:
            c_options.cipher_xform.cipher.key.length = AES_CBC_128_KEY_LENGTH;
            c_options.cipher_xform.cipher.key.data = aes_cbc_128_key;
            c_options.cipher_xform.cipher.algo = RTE_CRYPTO_CIPHER_AES_CBC;
            c_options.cipher_xform.cipher.iv.length = 0;
            c_options.cipher_xform.cipher.iv.offset = 0;

            c_options.auth_xform.auth.key.length = HMAC_KEY_LENGTH_SHA1;
            c_options.auth_xform.auth.key.data = hmac_sha1_key;
            c_options.auth_xform.auth.algo = RTE_CRYPTO_AUTH_SHA1_HMAC;
			c_options.auth_xform.auth.digest_length = 12;
            break;
        case 2:
        case 3:
            c_options.cipher_xform.cipher.key.length = AES_CBC_256_KEY_LENGTH;
            c_options.cipher_xform.cipher.key.data = aes_cbc_256_key;
            c_options.cipher_xform.cipher.algo = RTE_CRYPTO_CIPHER_AES_CBC;
            c_options.cipher_xform.cipher.iv.length = 0;
            c_options.cipher_xform.cipher.iv.offset = 0;

            c_options.auth_xform.auth.key.length = HMAC_KEY_LENGTH_SHA256;
            c_options.auth_xform.auth.key.data = hmac_sha256_key;
            c_options.auth_xform.auth.algo = RTE_CRYPTO_AUTH_SHA256_HMAC;
			c_options.auth_xform.auth.digest_length = 16;
            break;
        case 4:
        case 5:
            c_options.cipher_xform.cipher.key.length = AES_CBC_192_KEY_LENGTH;
            c_options.cipher_xform.cipher.key.data = aes_cbc_192_key;
            c_options.cipher_xform.cipher.algo = RTE_CRYPTO_CIPHER_AES_CBC;
            c_options.cipher_xform.cipher.iv.length = 0;
            c_options.cipher_xform.cipher.iv.offset = 0;

            c_options.auth_xform.auth.key.length = HMAC_KEY_LENGTH_SHA224;
            c_options.auth_xform.auth.key.data = hmac_sha224_key;
            c_options.auth_xform.auth.algo = RTE_CRYPTO_AUTH_SHA224_HMAC;
			c_options.auth_xform.auth.digest_length = 12;
            break;

    }
}

struct rte_security_session *initialize_crypto_session(uint8_t cdev_id)
{
    struct rte_crypto_sym_xform *first_xform;
    struct rte_security_session *session;
    struct rte_security_session_conf session_conf = {0};
    struct rte_mempool *sess_mp;

    int socket_id = rte_eth_dev_socket_id(cdev_id);
    sess_mp = session_pool_socket[socket_id];

#if RTE_VERSION >= RTE_VERSION_NUM(20, 11, 0, 0)
	struct rte_mempool *sess_priv_mp = session_priv_pool_socket[socket_id];
#endif

    switch(c_options.xform_chain)
    {
        case CRYPTO_IPSEC:
            first_xform = &c_options.cipher_xform;
            break;
        default:
            rte_panic("Invalid xform_chain %d\n", c_options.xform_chain);
            break;
    }

    /*Configure for rte security apis*/
    session_conf.action_type = RTE_SECURITY_ACTION_TYPE_INLINE_CRYPTO;
    session_conf.protocol = RTE_SECURITY_PROTOCOL_IPSEC;
    session_conf.ipsec = c_options.ipsec_xform;
    session_conf.crypto_xform = first_xform;

    struct rte_security_ctx *ctx;
    ctx = (struct rte_security_ctx *)rte_eth_dev_get_sec_ctx(cdev_id);
    /*Create session*/
#if RTE_VERSION >= RTE_VERSION_NUM(20, 11, 0, 0)
	session = rte_security_session_create(ctx,&session_conf, sess_mp, sess_priv_mp);
#else
	session = rte_security_session_create(ctx, &session_conf, sess_mp);
#endif
    if(session == NULL)
    {
        debug_print("Error while creating rte security session\n");
        return NULL;
    }

    return session;
}

void crypto_default_options(uint32_t num_session)
{
    enum rte_crypto_cipher_operation cipher_op;
    enum rte_crypto_auth_operation auth_op;

	debug_print("crypto_default_options %d\n",num_session);
	
    if(num_session % 2)
    {
        cipher_op = RTE_CRYPTO_CIPHER_OP_ENCRYPT;
        auth_op = RTE_CRYPTO_AUTH_OP_GENERATE;
    }
    else
    {
        cipher_op = RTE_CRYPTO_CIPHER_OP_DECRYPT;
        auth_op = RTE_CRYPTO_AUTH_OP_VERIFY;
    }

	
    switch (num_session)
    {
        case 0:
            set_cipher_params(num_session);

            /*Porting to rte secutity api*/
            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_INGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x0A010101);
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x14020201);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        case 1:
            set_cipher_params(num_session);

            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_EGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x0A010101);
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x14020201);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        case 2:
            set_cipher_params(num_session);

            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_INGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x0A010102);
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x14020202);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        case 3:
            set_cipher_params(num_session);

            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_EGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x0A010102);
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x14020202);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        case 4:
            set_cipher_params(num_session);

            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_INGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x0A010103);
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x14020203);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        case 5:
            set_cipher_params(num_session);

            c_options.ipsec_xform.direction = RTE_SECURITY_IPSEC_SA_DIR_EGRESS;
            c_options.ipsec_xform.tunnel.type = RTE_SECURITY_IPSEC_TUNNEL_IPV4;
            c_options.ipsec_xform.tunnel.ipv4.dst_ip.s_addr = (0x0A010103);
            c_options.ipsec_xform.tunnel.ipv4.src_ip.s_addr = (0x14020203);
            c_options.ipsec_xform.tunnel.ipv4.df = 0;
            c_options.ipsec_xform.tunnel.ipv4.ttl = 8;
            break;
        default:
            rte_panic("Invalid session number %d\n", num_session);
    }

    c_options.cipher_xform.cipher.op = cipher_op;
    c_options.auth_xform.auth.op = auth_op;
    c_options.xform_chain = CRYPTO_IPSEC; 

    /*Set Cipher Xform*/
    c_options.cipher_xform.type = RTE_CRYPTO_SYM_XFORM_CIPHER;
    c_options.cipher_xform.next = &c_options.auth_xform;

    /*Set Authentication Xform*/
    c_options.auth_xform.type = RTE_CRYPTO_SYM_XFORM_AUTH;
    c_options.auth_xform.next = NULL;

    /*Set IPSec xform*/
    memset(&c_options.ipsec_xform.options, 0, sizeof(struct rte_security_ipsec_sa_options));
    c_options.ipsec_xform.spi = 0;
    c_options.ipsec_xform.salt = 0;
    c_options.ipsec_xform.proto = RTE_SECURITY_IPSEC_SA_PROTO_ESP;
    c_options.ipsec_xform.mode = RTE_SECURITY_IPSEC_SA_MODE_TUNNEL;

}

int init_devices(void)
{
    unsigned int sz;

	num_vdevs = rte_eth_dev_count_avail();
	if (num_vdevs == 0)
        rte_panic("No ethernet ports found\n");
	
	if(num_vdevs > MAX_VDEVS)
		rte_panic("ethernet ports found %d > Maximum supported %d\n",num_vdevs,MAX_VDEVS);
	
	debug_print("Number of vdevs : %d\n",num_vdevs);

	if(egress_encrypt)
	{
		sz = NUM_SESSIONS_PER_DEV * sizeof(struct crypto_params);
		cparams = rte_malloc(NULL, sz, RTE_CACHE_LINE_SIZE);
		if(!cparams)
		{
			debug_print("Could not allocate memory for crypto instances\n");
			return -1;
		}
	}

    priv_size = APP_PRIV_DATA_SIZE;

#if 0
    /* Configure the mbuf pool with private data area for the NIC
     * bridge driver metadata and application metadata.
     */
    mp_nic = rte_pktmbuf_pool_create("packet_pool",
                     /* mbufs */ 16384 * num_vdevs * 8,
                     /* cache_size */ 512,
                     /* priv_size*/ priv_size,
                    // /* data_room_size */ RTE_MBUF_DEFAULT_BUF_SIZE,
					/* data_room_size */ 9728 + RTE_PKTMBUF_HEADROOM,
                     rte_socket_id());
#endif
    /* Configure the mbuf pool with private data area for the NIC
     * bridge driver metadata and application metadata.
     */
    mp_nic = rte_pktmbuf_pool_create("packet_pool",
                     /* mbufs */ 16384 * num_vdevs * 2,
                     /* cache_size */ 512,
                     /* priv_size*/ priv_size,
                     /* data_room_size */ RTE_MBUF_DEFAULT_BUF_SIZE,
					///* data_room_size */ 9728 + RTE_PKTMBUF_HEADROOM,
                     rte_socket_id());
	if(mp_nic == NULL)
    {
        debug_print("Could not allocate memory for mp_nic - Error %s\n",rte_strerror(rte_errno));
        return -1;
    }
					 
#ifdef MBUF_TX
    mp_nic_tx = rte_pktmbuf_pool_create("packet_pool_tx",
                     /* mbufs */ 16384 * num_vdevs * 4,
                     /* cache_size */ 512,
                     /* priv_size*/ priv_size,
                    /* data_room_size */ RTE_MBUF_DEFAULT_BUF_SIZE,
					//* data_room_size */ 9728 + RTE_PKTMBUF_HEADROOM,
                    /*rte_socket_id()*/SOCKET_ID_ANY );
	if(mp_nic_tx == NULL)
    {
        debug_print("Could not allocate memory for mp_nic_tx - Error %s\n",rte_strerror(rte_errno));
        return -1;
    }
#endif

    /* Configure the eth dev(s) */
    init_ports(num_vdevs, mp_nic);
	
	num_ports = rte_eth_dev_count_avail();
	debug_print("run_test: After Calling init_ports - num_ports %d\n",num_ports);

	if(egress_encrypt)
	{
		/* Configure the crypto devices */
		init_ports_crypto(1);
	}

    return 0;
}
