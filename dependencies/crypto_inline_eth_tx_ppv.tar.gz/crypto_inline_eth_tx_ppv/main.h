/*-
 *   BSD LICENSE
 *
 *   Copyright(c) 2016 Intel Corporation. All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "common.h"

#define APP_PRIV_DATA_SIZE	   32

#define NUM_HLP_PORTS          20
#define STAT_NAME_LENGTH       20
#define TOTAL_TESTS            3 
#define SINGLE_PORT_PACKETS    100
#define ALL_PORT_PACKETS       2000


extern int num_vdevs;
extern int seperate_thread_completion;
extern volatile uint32_t port_flags[];
extern volatile bool test_done_v;
extern int port_speed[];
extern unsigned int num_use_ports;
extern unsigned int start_port;
extern bool egress_encrypt;
extern bool use_snake;
extern int snake_start_port;

extern volatile uint32_t curr_port_num_rx[];
extern volatile uint32_t curr_port_num_tx[];

int nic_monitor_rx(void *arg);
int nic_monitor_tx(void *arg);
int Monitor_func(void *arg);


int setup_port_to_queue_mapping(void);

int init_devices(void);

int initialize_crypto_inst(uint8_t port_id);

int init_ports_crypto(unsigned num_ports);

void custom_function(void);

int completion_queue_thread(void *arg);
void print_cpq_stats_q(uint32_t qid);
void print_drop_stats_q(uint32_t qid);
void print_sa_error_stats_q(uint32_t qid);
int start_snake_traffic(int snake_start_port);
int delete_snake(void);
int create_snake(void);

//#define MBUF_TX 
#ifdef MBUF_TX
extern struct rte_mempool *mp_nic_tx;
#endif