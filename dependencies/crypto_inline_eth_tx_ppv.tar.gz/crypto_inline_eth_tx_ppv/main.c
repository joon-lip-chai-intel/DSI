/*-
 *   BSD LICENSE
 *
 *   Copyright(c) 2016 Intel Corporation. All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


/*************************************************************************************
 * The purpose of this application is to test end to end traffic path which includes
 * RX: Ixia -> RMN -> HLP -> CPK -> CPK PMD ->  Ethdev app
 * TX: Ethdev app -> CPK PMD -> CPK -> HLP -> RMN -> Ixia
 *************************************************************************************
 * The scenario for bridge driver is
 *
 *
 *      Application
 *    ------------------------------------
 *    ^                                  |
 *    |                                  |
 *    |                                  v
 *    Ethdev RX                      Ethdev TX
 *    ^                                  |
 *    |                                  |
 *    |                                  v
 *  +---------------------------------------+
 *  |         CPK PMD                       |
 *  |                                       |
 *  +---------------------------------------+
 *    ^                                  |
 *    |                                  |
 *    |                                  v
 *  +---------------------------------------+
 *  |              CPK                      |
 *  |                                       |
 *  +---------------------------------------+
 *    ^                                   |
 *    |                                   |
 *    |                                   v
 *  +----------------------------------------+
 *  |              HLP                       |
 *  |                                        |
 *  +----------------------------------------+
 *    ^                                   |
 *    |                                   |
 *    |                                   v
 *  +----------------------------------------+
 *  |              RMN                       |
 *  |                                        |
 *  +----------------------------------------+
 *    ^                                   |
 *    |                                   |
 *    |                                   v
 *  +----------------------------------------+
 *  |              Ixia                  |
 *  |                                        |
 *  +----------------------------------------+
 *
 ********************************************************************************/

#include "main.h"
#include "lib_socket.h"
#include "congestion_common.h"

bool set_completion = false;

int quiet = 0;
int vsi_number;

size_t num_packets;
int congestion = 0;
int destPort = 99;
bool egress_encrypt = true;
int rx_path = 0;
int tx_path = 0;
unsigned int pkt_len = 250;
unsigned int tx_burst_len = 16;
bool manual_input = false;
bool use_snake = true;
int snake_start_port = 0;

unsigned int ies_rx_frames, ies_tx_frames;

/********Crypto declarations***********/
struct rte_mempool *session_pool_socket[RTE_MAX_NUMA_NODES] = {0};
#if RTE_VERSION >= RTE_VERSION_NUM(20, 11, 0, 0)
 struct rte_mempool *session_priv_pool_socket[RTE_MAX_NUMA_NODES] = {0};
#endif
unsigned int num_cdevs;
struct crypto_options c_options = {0};
struct crypto_params *cparams;
/**************************************************/
uint8_t aes_cbc_128_iv_key[] = {
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F};

uint8_t aes_cbc_256_iv_key[] = {
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
    0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F};

uint8_t aes_cbc_192_iv_key[] = {
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57};
/***********************************************/
/***********************************************/
uint8_t aes_cbc_128_key[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};

uint8_t aes_cbc_256_key[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F};

uint8_t aes_cbc_192_key[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};
/*************************************************/
/*************************************************/
uint8_t hmac_sha256_key[] = {
        0xff, 0xcb, 0x37, 0x30, 0x1d, 0x4a, 0xc2, 0x41,
        0x49, 0x03, 0xDD, 0xC6, 0xB8, 0xCA, 0x55, 0x7A,
        0x58, 0x34, 0x85, 0x61, 0x1C, 0x42, 0x10, 0x76,
        0x9a, 0x4f, 0x88, 0x1b, 0xb6, 0x8f, 0xd8, 0x60};

uint8_t hmac_sha1_key[] = {
        0xff, 0xcb, 0x37, 0x30, 0x1d, 0x4a, 0xc2, 0x41,
        0x49, 0x03, 0xDD, 0xC6, 0xB8, 0xCA, 0x55, 0x7A,
        0x58, 0x34, 0x85, 0x61};

uint8_t hmac_sha224_key[] = {
        0xff, 0xcb, 0x37, 0x30, 0x1d, 0x4a, 0xc2, 0x41,
        0x49, 0x03, 0xDD, 0xC6, 0xB8, 0xCA, 0x55, 0x7A,
        0x58, 0x34, 0x85, 0x61, 0x1C, 0x42, 0x10, 0x76,
        0x8d, 0x3d, 0x6a, 0x9f};

uint8_t hmac_sha384_key[] = {
        0xff, 0xcb, 0x37, 0x30, 0x1d, 0x4a, 0xc2, 0x41,
        0x49, 0x03, 0xDD, 0xC6, 0xB8, 0xCA, 0x55, 0x7A,
        0x58, 0x34, 0x85, 0x61, 0x1C, 0x42, 0x10, 0x76,
        0x9a, 0x4f, 0x88, 0x1b, 0xb6, 0x8f, 0xd8, 0x60,
        0x64, 0x83, 0xa9, 0x9e, 0x30, 0x91, 0xc3, 0xb2,
        0xc6, 0xd8, 0xf1, 0x7c, 0x59, 0x94, 0x31, 0xe4};

uint8_t hmac_sha512_key[] = {
        0xff, 0xcb, 0x37, 0x30, 0x1d, 0x4a, 0xc2, 0x41,
        0x49, 0x03, 0xDD, 0xC6, 0xB8, 0xCA, 0x55, 0x7A,
        0x58, 0x34, 0x85, 0x61, 0x1C, 0x42, 0x10, 0x76,
        0x9a, 0x4f, 0x88, 0x1b, 0xb6, 0x8f, 0xd8, 0x60,
        0x64, 0x83, 0xa9, 0x9e, 0x30, 0x91, 0xc3, 0xb2,
        0xc6, 0xd8, 0xf1, 0x7c, 0x59, 0x94, 0x31, 0xe4,
        0xc8, 0xe8, 0xa1, 0x86, 0xc3, 0xb7, 0xbc, 0xae,
        0xa4, 0x53, 0x78, 0xb4, 0x29, 0x04, 0x11, 0xbe};
/****************************************************/

int acl_tbl_index;
int rule_ids[TOTAL_RULES];
volatile bool test_done_v = 0;
bool test_done = 0;

int num_vdevs;
unsigned int num_ports;
uint16_t priv_size;
struct rte_mempool *mp_nic = NULL;
bool in_reset = false;
unsigned int num_hlp_ports = NUM_HLP_PORTS;
int num_rxq_per_port = NUM_RX_QUEUE_PER_PORT;
int num_txq_per_port = NUM_TX_QUEUE_PER_PORT;
unsigned int num_use_ports = 1;
unsigned int start_port = 0;
bool qat_order = false;
int link_speed = 0;
int link_4_100g = 0;
int link_4_50g = 0;

int num_cpus;
int num_lcores;

/* ipSec is true */
bool ipSec = true;

#ifndef STATS_64
uint32_t total_packets = 0;
uint32_t rx_packets_qid[MAX_HLP_PORTS * MAX_RX_QUEUE_PER_PORT];
uint32_t tx_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint32_t tx_drop_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint32_t tx_wred_drop_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint32_t cp_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint32_t sa_error_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
#else
uint64_t total_packets = 0;
uint64_t rx_packets_qid[MAX_HLP_PORTS * MAX_RX_QUEUE_PER_PORT];
uint64_t tx_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint64_t tx_drop_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint64_t tx_wred_drop_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint64_t cp_packets_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
uint64_t sa_error_qid[MAX_HLP_PORTS * MAX_TX_QUEUE_PER_PORT];
#endif

#ifdef MBUF_TX
struct rte_mempool *mp_nic_tx = NULL;
#endif

int num_sock_funcs = 0;
struct sock_function_table	sf_tab[MAX_SOCKET_FUNCS];

uint32_t active_ports[MAX_HLP_PORTS] ;
int num_active_ports = 0;
int seperate_thread_completion = 0;

volatile uint32_t port_flags[MAX_HLP_PORTS] ;
volatile uint32_t curr_port_num_rx[MAX_HLP_PORTS] ;
volatile uint32_t curr_port_num_tx[MAX_HLP_PORTS] ;


int port_speed[MAX_HLP_PORTS];

static struct option long_options[] = {
	{"quiet", no_argument, 0, 'q'},
	{"congestion", no_argument, 0, 'c'},
	{"ingressOnly", no_argument, 0, 'i'},
	{"egressOnly", no_argument, 0, 'e'},
	{"noencrypt", no_argument, 0, 'n'},
	{"manual", no_argument, 0, 'm'},
	{"destPort", required_argument, 0, 'd'},
	{"rxPerPort", required_argument, 0, 'r'},
	{"txPerPort", required_argument, 0, 't'},
	{"hlpPorts", required_argument, 0, 'p'},
	{"pktLength", required_argument, 0, 'l'},
	{"txBurstLength", required_argument, 0, 'b'},
	{"qatOrder", no_argument, 0, 'x'},
	{"linkSpeed", required_argument, 0, 'k'},
	{0, 0, 0, 0}
};

static void usage(void)
{
	const char *usage_str =
		"  Usage: ci_eth_tx [options]\n"
		"  Options:\n"
		"  -q, --quiet             	Minimize printed output\n"
		"  -c, --congestion        	Enable congestion\n"
		"  -i, --ingress       	   	Ingress Only\n"
		"  -e, --egress     		Egress Only\n"
		"  -m, --manual	            Manual Commands\n"
		"  -n, --noencrypt         	Do not Encrypt Egress packet\n"
		"  -d N, --destPort=N      	Do Tx on Port N\n"
		"  -r N, --rxPerPort=N     	Create N RxQs per port\n"
		"  -t N, --txPerPort=N     	Create N TxQs per port\n"
		"  -p N, --hlpPorts=N      	Use N HLP Ports\n"
		"  -s N, --startPort=N      Start port number N\n"
		"  -l N, --pktLength=N      Use Packet Length N for Tx\n"
		"  -b N, --txBurstLength=N  Use Burst Length N for Tx\n"
		"  -x, --qatOrder			Enable QAT Passthrough\n"
		"  -k N, --linkSpeed=N      Set linkSpeed to N\n"
		"\n";

	fprintf(stderr, "%s", usage_str);
	exit(1);
}

int check_port_active(uint32_t port);
int check_port_active(uint32_t port)
{
	int i;
	if(num_active_ports)
	{
		for (i=0;i<num_active_ports;i++)
		{
			if(port == active_ports[i])
			{
				debug_print("HLP Port %d is active\n",port);
				return 1;
			}
		}
		debug_print("HLP Port %d is inactive\n",port);
		return 0;
	}
	/* Assume port is active if port_list is not populated */
	return 1;
}


static void parse_app_args(int argc, char** argv)
{
	/* Parse cli options*/
	int option_index;
	int c;

	for (;;)
    {
		c = getopt_long(argc, argv, "qcienmxd:p:s:r:t:l:b:k:", long_options,
				&option_index);
		if (c == -1)
			break;

		switch (c)
        {
			case 'q':
				quiet = 1;
			break;
			case 'c':
				congestion = 1;
				debug_print("Congestion enabled\n");
			break;
			case 'i':
				rx_path = 1;
				debug_print("Ingress enabled\n");
			break;	
			case 'e':
				tx_path = 1;
				debug_print("Egress enabled\n");
			break;						
			case 'n':
				egress_encrypt = false;
				ipSec = false;
				debug_print("Crypto and Egress encryption disabled\n");
			break;
			case 'm':
				manual_input = true;
				debug_print("Manual Input enabled\n");
			break;
			case 'x':
				qat_order = true;
				debug_print("QAT Passthrough enabled\n");
			break;
			case 'd':
				destPort = (unsigned long )atol(optarg);
				debug_print("Tx Port is %d\n",destPort);
			break;
			case 'r':
				num_rxq_per_port = (unsigned long )atol(optarg);
				if(num_rxq_per_port > MAX_RX_QUEUE_PER_PORT)
				{
					debug_print("Number of Rx Port %d > max %d\nSet to %d\n",num_rxq_per_port,MAX_RX_QUEUE_PER_PORT,MAX_RX_QUEUE_PER_PORT);
					num_rxq_per_port = MAX_RX_QUEUE_PER_PORT;
				}
				/* Set value of set_num_rxq_per_port */
				set_num_rxq_per_port(num_rxq_per_port);
				debug_print("Number of Rx Port is %d\n",num_rxq_per_port);
			break;
			case 't':
				num_txq_per_port = (unsigned long )atol(optarg);
				if(num_txq_per_port > MAX_TX_QUEUE_PER_PORT)
				{
					debug_print("Number of Tx Port %d > max %d\nSet to %d\n",num_txq_per_port,MAX_TX_QUEUE_PER_PORT,MAX_TX_QUEUE_PER_PORT);
					num_txq_per_port = MAX_TX_QUEUE_PER_PORT;
				}
				/* Set value of set_num_txq_per_port */
				set_num_txq_per_port(num_txq_per_port);
				debug_print("Number of Tx Port is %d\n",num_txq_per_port);
			break;
			case 'p':
				num_use_ports = (unsigned long )atol(optarg);
				if(num_use_ports > MAX_HLP_PORTS)
				{
					debug_print("Number of HLP Ports %d > max %d\nSet to %d\n",num_use_ports,MAX_HLP_PORTS,MAX_HLP_PORTS);
					num_use_ports = MAX_HLP_PORTS;
				}
				debug_print("Number of HLP Ports to use is %d\n",num_use_ports);
			break;
			case 's':
				start_port = (unsigned long )atol(optarg);
				debug_print("Start Port number is %d\n",start_port);
			break;
			case 'l':
				pkt_len = (unsigned long )atol(optarg);
				debug_print("Transmit packet length is %d\n",pkt_len);
			break;
			case 'b':
				tx_burst_len = (unsigned long )atol(optarg);
				debug_print("Transmit Burst length is %d\n",tx_burst_len);
			break;
			case 'k':
				link_speed = (unsigned long )atol(optarg);
				debug_print("Link Speed is %d\n",link_speed);
			break;
			default:
				usage();
		}
	}
}

void test_exit(int exit_code)
{
	int ret;

#ifndef STATS_64
	debug_print("Total Packets = %d\n", total_packets);
#else
	debug_print("Total Packets = %lu\n", total_packets);
#endif
	debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
	
    debug_print("test_exit: Cleaning up \n");

	if(congestion)
		cleanup_congestion();
	
	if (egress_encrypt)
	{
		ret = clean_ipsec_crypto();
		if(ret != 0)
		{
			debug_print("clean_ipsec_crypto failed\n");
			exit_code = 1;
		}
	}
	
	if(use_snake)
	{
		delete_snake();
	}
	
    clean_eth();
	
	cleanup_hlp();
	
    ies_terminate(false);

	switch(exit_code)
    {
		case 0:
			debug_print("TEST RESULT: TEST PASSED\n");
			exit(EXIT_SUCCESS);
		break;

		default:
			debug_print("TEST RESULT: TEST Failed\n");
			exit(EXIT_FAILURE);
	}
}

pthread_t start_thread(int (*functionPtr)(void *), void *arg, const char *thread_name,
        pthread_attr_t *pthread_attr)
{
	pthread_t	tid;
	int err;

	if (strlen(thread_name)*sizeof(char) > RTE_MAX_THREAD_NAME_LEN)
		rte_panic("thread name too long\n");


    err = pthread_create(&tid, pthread_attr, (void *)(*functionPtr), arg);

	if (err)
		rte_panic("Cannot create thread %s\n", thread_name);

	err = rte_thread_setname(tid, thread_name);
	if (err)
		rte_panic("Cannot set thread name %s\n", thread_name);

	debug_print("Start thread %s\n", thread_name);
    return tid;
}

void CtrlCHdlr(int sig) 
{
	printf("\nBreak with <ctrl-c> %d\n",sig);
	test_done_v = 1;
	test_done = 1;

}

/* Custom Socket stub function */
void custom_function(void)
{
	printf("custom_function called \n");
}

void set_thread_affinity(pthread_t pid, int core_id);

void set_thread_affinity(pthread_t pid, int core_id)
{
	int ret;
  // cpu_set_t: This data set is a bitset where each bit represents a CPU.
  cpu_set_t cpuset;
  // CPU_ZERO: This macro initializes the CPU set set to be the empty set.
  CPU_ZERO(&cpuset);
  // CPU_SET: This macro adds cpu to the CPU set set.
  CPU_SET(core_id, &cpuset);
  ret = pthread_setaffinity_np(pid, sizeof(cpu_set_t), &cpuset);
  if (ret != 0) {
     debug_print( "pthread_setaffinity_np - error %d\n",ret);
  }
 ret = pthread_getaffinity_np(pid, sizeof(cpu_set_t), &cpuset);
 if (ret != 0) {
     debug_print( "pthread_getaffinity_np - error %d\n",ret);
  }
  if (CPU_ISSET(core_id, &cpuset)) {
	  debug_print( "Thread running on core_id %d\n",core_id);
  }
}



int main(int argc, char **argv)
{
	int err;
	bool shared_memory = true, is_master = false;

	int i;
	uint32_t thread_arg[MAX_HLP_PORTS];
	struct rte_eth_dev_info dev_info;
	int required_cores=0;
	


	unsigned int lcore;
	lcore =  rte_lcore_id();
	debug_print("lcore initialized to %d\n",lcore);

	
	/*This handler prints the PDU received by respective thread and exits*/
    (void) signal(SIGINT, CtrlCHdlr);
	
	/* Get Active port list from test system CSV file */
	num_active_ports = get_active_port_list(active_ports);
	
	/* Do not set links on startp */
	set_link_on_startup(0);
    /*adding function to setup hlp*/
    setup_hlp(shared_memory, is_master);
	
	debug_print("Calling rte_eal_init\n");
    err = rte_eal_init(argc, argv);
	if (err < 0)
		rte_panic("Invalid EAL arguments\n");
	debug_print("After rte_eal_init\n");
	
	argc -= err;
	argv += err;

	/* Parse cli options*/
	parse_app_args(argc, argv);
	
	if(rx_path == 0 && tx_path == 0)
	{
		debug_print("Rx and Tx are not set - setting Rx as default \n");
		rx_path = 1;
	}
	
	
	num_cpus = sysconf(_SC_NPROCESSORS_ONLN); // Get the number of logical CPUs
	num_lcores = rte_lcore_count();
	debug_print("Number of CPUs: %d\n",num_cpus);
	debug_print("Number of lcores: %d\n",rte_lcore_count());

	if(rx_path )
	{
		required_cores = num_use_ports;
	}
	if( tx_path)
	{
		required_cores += num_use_ports;
	}
	
	if( required_cores > num_lcores - 2)
	{
		debug_print("Number of cores required %d is greater than available cores %d .. exiting test\n",required_cores,num_lcores -2);
		test_exit(1);
	}
			
	if((start_port + num_use_ports) > MAX_HLP_PORTS)
	{
		debug_print("Number of HLP Ports to use %d > max %d\n Start port set to %d\n",start_port + num_use_ports,MAX_HLP_PORTS,0);
		start_port = 0;
	}
	debug_print("Start Port number is %d\n",start_port);
	num_vdevs = rte_eth_dev_count_avail();
	if (num_vdevs == 0)
        rte_panic("No ethernet ports found\n");
	
	if(num_vdevs > MAX_VDEVS)
		rte_panic("ethernet ports found %d > Maximum supported %d\n",num_vdevs,MAX_VDEVS);

	debug_print("Number of vdevs : %d\n",num_vdevs);
	
	/* Get dev_inf for vdev 0 */
	rte_eth_dev_info_get(0, &dev_info);

#ifdef RING2K
	debug_print("Setting Rx/Tx ring size to 2K\n");
	set_tx_ring_size(2048);
	set_rx_ring_size(2048);
#endif
	
    /*Setup test*/
	disable_wred();
    debug_print("Calling init_devices()\n");
    err = init_devices();
    if(err != 0)
		test_exit(1);
    
	if(congestion)
	{
		//set_congestion_type(CG_64_PIN);
		set_congestion_type(CG_32_PIN);
		setup_congestion();
	}
	
	debug_print("rte_mempool_avail_count(mp_nic): %d\n",rte_mempool_avail_count(mp_nic));
    /*Setup HLP port to queue mappings*/
    if(setup_port_to_queue_mapping() != 0)
    {
        debug_print("port to queue mapping failed\n");
        test_exit(1);
    } 
	
  	/* Setup default socket function table */
	setup_default_sf_table();
	
	/*Add Custom socket function */
	if (add_custom_sf("CustomFunction",&custom_function))
	{
		printf("add_custom_sf failed \n");
	}
	
   
    debug_print("Running test \n");
	
	/*Start SocketServer thread */
 	start_thread(&socketServer, NULL, "socketServer", NULL);
	
	/*Start Monitor thread */
 	start_thread(&Monitor_func, NULL, "Monitor_func", NULL);
	
#if 0
	debug_print("wait for links to come up ...\n");
	sleep(5);	
#endif

	if(link_speed == 50)
	{
		uint64_t phy_ability;
		ies_port_get_attr(0, 0, IES_PA_PHY_TYPE_ABILITY, &phy_ability);
		if (!(IES_PORT_PHY_TYPE_50GBASE_LAUI2 & phy_ability))
		{
			link_speed = 0;
			debug_print("This SKU does not support Link Speed of 50G setting link speed to default %d\n",link_speed);
		}
		ies_port_get_attr(0, 15, IES_PA_PHY_TYPE_ABILITY, &phy_ability);
		if ((IES_PORT_PHY_TYPE_50GBASE_LAUI2 & phy_ability))
		{
			link_4_50g = 1;
			debug_print("This SKU supports Link Speed of 50G on 4 ports %d\n",link_speed);
		}
	}
	if(link_speed == 100)
	{
		uint64_t phy_ability;
		ies_port_get_attr(0, 0, IES_PA_PHY_TYPE_ABILITY, &phy_ability);
		if (!(IES_PORT_PHY_TYPE_100G_CAUI4 & phy_ability))
		{
			link_speed = 0;
			debug_print("This SKU does not support Link Speed of 100G setting link speed to default %d\n",link_speed);
		}
		ies_port_get_attr(0, 15, IES_PA_PHY_TYPE_ABILITY, &phy_ability);
		if ((IES_PORT_PHY_TYPE_100G_CAUI4 & phy_ability))
		{
			link_4_100g = 1;
			debug_print("This SKU supports Link Speed of 100G on 4 ports %d\n",link_speed);
		}
	}
	
	for (i=0;i<(int)num_hlp_ports;i++)
	{
		port_speed[i] = 10; //Set to 10Gb by default
		if(!is_port_enabled(i))
		{
			continue;
		}
		if(check_port_active(i))
		{
#ifdef ASIC
			if(link_speed == 0 || link_speed == 25) /* Set port links spped  to 25G */
			{
			/* Set ports to 25G */
			/* 8C systems have ports 0..7 as 10G */
			if (i < 8 || i > 11)
			{
				/* ports 0-7 are 10G on 8 core systems */
				if(num_cpus > 8 ||  i > 11)
				{
#ifdef IES_PORT_PHY_TYPE_25G_AUI_C2C
					debug_print("Port %d link is down - setting to IES_PORT_PHY_TYPE_25G_AUI_C2C\n",i);
					set_phy_type(i,IES_PORT_PHY_TYPE_25G_AUI_C2C);
#else
					debug_print("Port %d link is down - setting to IES_PORT_PHY_TYPE_25G_AUI\n",i);
					set_phy_type(i,IES_PORT_PHY_TYPE_25G_AUI);
#endif	
					port_speed[i] = 25; //Set to 25Gb
				}
				else
				if(num_cpus <= 8 && i < 8)
				{
#ifdef IES_PORT_PHY_TYPE_10G_SFI_DA
					debug_print("Port %d link is down - setting to IES_PORT_PHY_TYPE_10G_SFI_DA\n",i);
					set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI_DA);
#else
					debug_print("Port %d link is down - setting to IES_PORT_PHY_TYPE_10G_SFI\n",i);
					set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI);
#endif	
				}
			}
			else
			{
				debug_print("Port %d link is down - setting to IES_PORT_PHY_TYPE_10G_SFI\n",i);
				set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI);
				port_speed[i] = 10; //set to 10Gb
			}
			}
			else
			if( link_speed == 1)
			{
				set_phy_type(i,IES_PORT_PHY_TYPE_1000BASE_X);
				debug_print("Port %d - setting to IES_PORT_PHY_TYPE_1000BASE_X\n",i);
				port_speed[i] = 1; //Set to 1Gb
				if( i >= 0 && i <= 7)
				{
					usleep(300000);
				}
			}
			else
			if( link_speed == 2)
			{
				set_phy_type(i,IES_PORT_PHY_TYPE_2500BASE_X);
				debug_print("Port %d - setting to IES_PORT_PHY_TYPE_2500BASE_X\n",i);
				port_speed[i] = 2.5; //Set to 2.5Gb
			}	
			else
			if( link_speed == 10)
			{
				set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI);
				debug_print("Port %d - setting to IES_PORT_PHY_TYPE_10G_SFI\n",i);
				port_speed[i] = 10; //set to 10Gb
			}	
			else
			if( link_speed == 50 || link_speed == 100)
			{
				if(i == 0 || i== 7)
				{
					if(i == 0)
					{
						for(int j = 0; j <=7; j++)
						{
							if (is_port_enabled(j))
							{
								debug_print("Preparing for Multilane mode, Disabling Port %d phy\n", j);
								set_phy_type(j,IES_PORT_PHY_TYPE_DISABLED);
							}
						}
						debug_print("Waiting for Port 0..7 phy to be disabled\n");
						while(1)
						{
							if (!get_link_state(7) )
								break;
						}
						debug_print("Port 0..7 phy disabled\n");
					}
					if(link_speed == 50)
					{
						debug_print("Port %d - setting to IES_PORT_PHY_TYPE_50GBASE_LAUI2\n",i);
						set_phy_type(i,IES_PORT_PHY_TYPE_50GBASE_LAUI2);
						port_speed[i] = 50; //Set to 50Gb
					}
					else
					{
						debug_print("Port %d - setting to IES_PORT_PHY_TYPE_100G_CAUI4\n",i);
						set_phy_type(i,IES_PORT_PHY_TYPE_100G_CAUI4);
						port_speed[i] = 100; //Set to 100Gb
					}
				}
				else
				if(i > 7 && i <= 11)
				{
					set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI);
					debug_print("Port %d - setting to IES_PORT_PHY_TYPE_10G_SFI\n",i);
					port_speed[i] = 10; //set to 10Gb
				}
				else
				{
					if( link_4_100g || link_4_50g)
					{
						if(i == 15 || i== 16)
						{
							if( i== 15)
							{
								for(int j = 12; j <=19; j++)
								{
									if (is_port_enabled(j))
									{
										debug_print("Preparing for Multilane mode, Disabling Port %d phy\n", j);
										set_phy_type(j,IES_PORT_PHY_TYPE_DISABLED);
									}
								}
								debug_print("Waiting for Port 12..19 phy to be disabled\n");
								while(1)
								{
									if (!get_link_state(19) )
										break;
								}
								debug_print("Port 12.19 phy disabled\n");
							}
							if(link_speed == 50)
							{
								debug_print("Port %d - setting to IES_PORT_PHY_TYPE_50GBASE_LAUI2\n",i);
								set_phy_type(i,IES_PORT_PHY_TYPE_50GBASE_LAUI2);
								port_speed[i] = 50; //Set to 50Gb
							}
							else
							{
								debug_print("Port %d - setting to IES_PORT_PHY_TYPE_100G_CAUI4\n",i);
								set_phy_type(i,IES_PORT_PHY_TYPE_100G_CAUI4);
								port_speed[i] = 100; //Set to 100Gb
							}
						}
					}
					else
					{
						set_phy_type(i,IES_PORT_PHY_TYPE_10G_SFI);
						debug_print("Port %d - setting to IES_PORT_PHY_TYPE_10G_SFI\n",i);
						port_speed[i] = 10; //set to 10Gb
					}
				}
			}
#endif
			port_flags[i] = 0 ;
		}
	}

	
	for (i=start_port;i<(int)(start_port + num_use_ports);i++)
	{
		if(link_speed >= 50 && (i > 0 && i < 7))
		{
			continue;
		}
		if(check_port_active(i))
		{		
			if(rx_path)
			{
				lcore =  rte_get_next_lcore(lcore , 1, 0);
				/* check and reset lcore to first core if max_lcore is reached */
				if(lcore == RTE_MAX_LCORE)
				{
					lcore =  rte_lcore_id();
					lcore =  rte_get_next_lcore(lcore , 1, 0);
				}
				debug_print("Calling rte_eal_remote_launch() for nic_monitor_rx(%d) on lcore %d\n",i,lcore);
				thread_arg[i] = i;
				curr_port_num_rx[i] = i;
				rte_eal_remote_launch(nic_monitor_rx, (uint32_t *)&thread_arg[i], lcore);
			}
			if(tx_path)
			{
		
				lcore =  rte_get_next_lcore(lcore , 1, 0);
				/* check and reset lcore to first core if max_lcore is reached */
				if(lcore == RTE_MAX_LCORE)
				{
					lcore =  rte_lcore_id();
					lcore =  rte_get_next_lcore(lcore , 1, 0);
				}
				debug_print("Calling rte_eal_remote_launch() for nic_monitor_tx(%d) on lcore %d\n",i,lcore);
				thread_arg[i] = i;
				curr_port_num_tx[i] = i;
				rte_eal_remote_launch(nic_monitor_tx, (uint32_t *)&thread_arg[i], lcore);
			}
		}

	}

	/* Create a completion queue processing thread if there is Tx and 1 CPQ per vdev */
	/* Else, do completion queue processing  in the txq thread */
	if((dev_info.max_cp_queues == 1) && (dev_info.max_cp_queues < num_hlp_ports) && tx_path)
	{
		seperate_thread_completion = 1;
		lcore =  rte_get_next_lcore(lcore , 1, 0);
		/* check and reset lcore to first core if max_lcore is reached */
		if(lcore == RTE_MAX_LCORE)
		{
			lcore =  rte_lcore_id();
			lcore =  rte_get_next_lcore(lcore , 1, 0);
		}
		debug_print("Calling rte_eal_remote_launch() for completion_queue_thread() on lcore %d\n",lcore);
		rte_eal_remote_launch(completion_queue_thread, NULL, lcore);

	}

	/* wait for eal_threads to exit */
	rte_eal_mp_wait_lcore();

    test_exit(0);

	return 0;
}



int Monitor_func(void *arg)
{
	RTE_SET_USED(arg);
    char opt_str[32];
	unsigned int i, port_num,qid,start_qid,end_qid;
	int got_str = 0;
	
	FILE *fp = NULL ;

	char cliCmd[]="reset port stats all";
	ies_cli_exec_command(cliCmd, sizeof(cliCmd) - 1, printf);
	
	char traffic_type[8];
	if( egress_encrypt)
		sprintf(traffic_type,"ipsec");
	else
		sprintf(traffic_type,"clear");
	
	if(!manual_input)
	{
		fp = fopen ("/tmp/ci_eth_tx_opt", "w+");
		if(!fp)
		{
			debug_print("Could not create file /tmp/ci_eth_tx_opt -- exiting monitor thread\n");
			return(-1);
		}
	}
	printf("\nEnter your choice ?Help S<port_num/A> - Start Tx T<port_num/A> - Stop Tx P<port_num/A> - Print Stats C<<port_num/A> - Clear Stats E. Exit\n");
    while(!test_done_v)
	{
		if(!manual_input)
		{
			fseek(fp, 0, SEEK_SET);
			if (fgets(opt_str, 32, fp) != NULL)
			{
				got_str = 1;
			}
		}
		else
		{
			scanf("%s",opt_str);
			got_str = 1;
		}
		if(got_str)
		{
			printf("%s\n",opt_str);

			switch(toupper(opt_str[0]))
			{
				case 'X':
				{
					port_num = strtol(&opt_str[1],NULL,10);
					int j = port_num;
					printf("Setting start_port from %d to %d\n",start_port,port_num);
					for (i=start_port;i<(int)(start_port + num_use_ports);i++)
					{
						if(!is_port_enabled(i))
						{
							j++;
							continue;
						}
						if(check_port_active(i))
						{
							printf("Switching from port %d to %d\n",i,j);
							curr_port_num_rx[i] =  j;
							curr_port_num_tx[i] =  j;
						}
						j++;
					}
					start_port = port_num;
				}
				break;
				case 'E':
				{
					test_done_v = 1;
					test_done = 1;
				}
				break;
				case 'S':
				{
					if(toupper(opt_str[1]) == 'A')
					{
						printf("Starting %s Tx on all active ports\n",traffic_type);
						for (i=start_port;i<(start_port + num_use_ports);i++)
						{
							if(!is_port_enabled(i))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((i == 0 || i ==  7) || (( i==15 || i== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(i))
							{
								printf("Starting %s Tx on Port %d\n",traffic_type,i);
								port_flags[i] = 1;
							}
						}
					}
					else if(toupper(opt_str[1]) == 'S')
					{
						if(use_snake)
						{
							printf("Starting Clear Snake traffic on port %d\n",snake_start_port);
							create_snake();
							start_snake_traffic(snake_start_port);
						}
						else
						{
							printf("Snake option not enabled\n");
						}
					}
					else
					{
						port_num = strtol(&opt_str[1],NULL,10);
						if((port_num >= start_port) && (port_num < start_port +  num_use_ports))
						{
							if(!is_port_enabled(port_num))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((port_num == 0 || port_num ==  7) || (( port_num==15 || port_num== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(port_num))
							{
								printf("Starting Tx on Port %d\n",port_num);
								port_flags[port_num] = 1;
							}
						}
					}
				}
				break;
				case 'T':
				{
					if(toupper(opt_str[1]) == 'A')
					{
						printf("Stopping Tx on all active ports\n");
						for (i=start_port;i<(start_port + num_use_ports);i++)
						{
							if(!is_port_enabled(i))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((i == 0 || i ==  7) || (( i==15 || i== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(i))
							{
								printf("Stopping Tx on Port %d\n",i);
								port_flags[i] = 0;
							}
						}
					}
					else if(toupper(opt_str[1]) == 'S')
					{
						if(use_snake)
						{
							printf("Deleting snake\n");
							delete_snake();
						}
						else
						{
							printf("Snake option not enabled\n");
						}
					}
					else
					{
						port_num = strtol(&opt_str[1],NULL,10);
						if((port_num >= start_port) && (port_num < start_port +  num_use_ports))
						{
							if(!is_port_enabled(port_num))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((port_num == 0 || port_num ==  7) || (( port_num==15 || port_num== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(port_num))
							{
								printf("Stopping Tx on Port %d\n",port_num);
								port_flags[port_num] = 0;
							}
						}
					}
				}
				break;
				case 'P':
				{
					if(toupper(opt_str[1]) == 'A')
					{
						printf("Printing Stats on all active ports\n");
						for (i=start_port;i<(start_port + num_use_ports);i++)
						{
							if(!is_port_enabled(i))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((i == 0 || i ==  7) || (( i==15 || i== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(i))
							{
								start_qid = i * num_rxq_per_port;
								end_qid = start_qid + num_rxq_per_port;
								for(qid = start_qid; qid < end_qid; qid++)
								{
									print_stats_q(qid);
									if (!seperate_thread_completion)
									{
										print_cpq_stats_q(qid);
									}
									print_drop_stats_q(qid);
									if(rx_path)
									{
										print_sa_error_stats_q(qid);
									}
								}
							}
						}
					}
					else
					{
						port_num = strtol(&opt_str[1],NULL,10);
						if((port_num >= start_port) && (port_num < start_port +  num_use_ports))
						{
							if(!is_port_enabled(port_num))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((port_num == 0 || port_num ==  7) || (( port_num==15 || port_num== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(port_num))
							{
								start_qid = port_num * num_rxq_per_port;
								end_qid = start_qid + num_rxq_per_port;
								for(qid = start_qid; qid < end_qid; qid++)
								{
									print_stats_q(qid);
									if (!seperate_thread_completion)
									{
										print_cpq_stats_q(qid);
									}
									print_drop_stats_q(qid);
									if(rx_path)
									{
										print_sa_error_stats_q(qid);
									}
								}
							}
						}
					}
				}
				break;
				case 'C':
				{
					if(toupper(opt_str[1]) == 'A')
					{
						printf("Clearing stats on all active ports\n");
						for (i=start_port;i<(start_port + num_use_ports);i++)
						{
							if(!is_port_enabled(i))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((i == 0 || i ==  7) || (( i==15 || i== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(i))
							{
								start_qid = i * num_rxq_per_port;
								end_qid = start_qid + num_rxq_per_port;
								for(qid = start_qid; qid < end_qid; qid++)
								{
									rx_packets_qid[qid]=tx_packets_qid[qid] = tx_drop_packets_qid[qid]=tx_wred_drop_packets_qid[qid]=cp_packets_qid[qid]=0;
								}
							}
						}
						char cliCmd[]="reset port stats all";
						printf("%s\n",cliCmd);
						ies_cli_exec_command(cliCmd, sizeof(cliCmd) - 1, printf);
					}
					else
					{
						port_num = strtol(&opt_str[1],NULL,10);
						if((port_num >= start_port) && (port_num < start_port +  num_use_ports))
						{
							if(!is_port_enabled(port_num))
							{
								continue;
							}
							if(link_speed >= 50)
							{
								if (!((port_num == 0 || port_num ==  7) || (( port_num==15 || port_num== 16 ) && (link_4_100g || link_4_50g))))
								{
									continue;
								}
							}
							if(check_port_active(port_num))
							{
								start_qid = port_num * num_rxq_per_port;
								end_qid = start_qid + num_rxq_per_port;
								for(qid = start_qid; qid < end_qid; qid++)
								{
									rx_packets_qid[qid]=tx_packets_qid[qid] = tx_drop_packets_qid[qid]=tx_wred_drop_packets_qid[qid]=cp_packets_qid[qid]=0;
								}
							}
						}
					}
				}
				break;
				default:
				break;
			}
			printf("\nEnter your choice ?Help S<port_num/A> - Start Tx T<port_num/A> - Stop Tx P<port_num/A> - Print Stats C<<port_num/A> - Clear Stats E. Exit\n");
			got_str = 0;
			if(!manual_input)
			{
				fclose(fp);
				fp = fopen ("/tmp/ci_eth_tx_opt", "w+");
			}
		}
	}
	
	if(!manual_input)
	{
		fclose(fp);	
	}
    printf("Monitor Thread Exiting\n");
	return(0);
 }
